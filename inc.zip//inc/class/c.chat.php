﻿<?php if ( ! defined('TS_HEADER')) exit('No se permite el acceso directo al script');
/**
 * Modelo para el control del chat
 *
 * @name    c.chat.php
 * @author  RhuanCarlos
 */
class tsChat {
	
	// ENVIAR UN MENSAJE NUEVO
	public function sendMessage() {
		global $tsCore, $tsUser;
		
		$time = time();
		
		$checkBan = db_exec(array(__FILE__, __LINE__), 'query', "SELECT ban_expire FROM c_chat_blacklist WHERE ban_user = '{$tsUser->uid}' LIMIT 1");
		$checkCount = db_exec('num_rows', $checkBan);
		$checkBan = db_exec('fetch_array', $checkBan);
		
		if(time() > $checkBan['ban_expire']) {
			db_exec(array(__FILE__, __LINE__), 'query', "DELETE FROM c_chat_blacklist WHERE ban_user = '{$tsUser->uid}'");
			$checkCount = 0;
		}
		
		if($checkCount == 0) {
			
			if(isset($_SESSION['lmsg']) && isset($_SESSION['floco'])) {
				if($_SESSION['lmsg'] > $time - 2) $_SESSION['floco'] += 1;
				else $_SESSION['floco'] = 0;
				
				$_SESSION['lmsg'] = $time;
				
				if($_SESSION['floco'] >= 4 && !$tsUser->is_admod) {
					$expire = $time + 7200;
					db_exec(array(__FILE__, __LINE__), 'query', "INSERT INTO c_chat_blacklist (ban_user, ban_expire, ban_date) VALUES ('{$tsUser->uid}', '{$expire}', '{$time}')");
				}
			}else {
				$_SESSION['lmsg'] = $time;
				$_SESSION['floco'] = 0;
			}
			
			$message = $tsCore->setSecure($_GET['message']);
			
			if(!empty($message)) {
				if(strlen($message) <= 500){
					$query = db_exec(array(__FILE__, __LINE__), 'query', "INSERT INTO c_chat_messages (msg_user, msg_text, msg_date) VALUES ('{$tsUser->uid}', '{$message}', '{$time}')");
					$update = db_exec(array(__FILE__, __LINE__), 'query', "UPDATE u_miembros SET user_chat = {$time} WHERE user_id = {$tsUser->uid}");
					$data = array('error' => false);
				}else {
					$data = array('error' => true, 'message' => 'El mensaje no puede superar los 500 caracteres.');
				}
			}else {
				$data = array('error' => true, 'message' => 'Escribe un mensaje.');
			}
		}else {
			$data = array('error' => true, 'message' => 'No puedes chatear, tu cuenta ha sido suspendida ('.$this->chatDate($checkBan['ban_expire']).')');
		}
		
		return json_encode($data);
	}
	
	// DAR FORMATO A LA FECHA
	public function chatDate($val, $type = 1){
		if($type == 1) {
			$meses = array('undefined', 'ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic');
			$fecha = date('d ', $val).$meses[date('n', $val)].date(' Y, H:i', $val);
		}else {
			$fecha = date('H:i', $val);
		}
		return $fecha;
	}
	
	// TRANSFORMAR A EMOTICONO
	public function parseSmiles($string) {
		$query = db_exec(array(__FILE__, __LINE__), 'query', "SELECT word, swop FROM w_badwords WHERE type = 1");
        
        foreach($query AS $badword) {
			$string = str_ireplace($badword['word'], '<img src="'.$badword['swop'].'" onclick="chat.addEmote(this)" alt="'.$badword['word'].'" class="chat_img">', $string);
		}
		return $string;
	}
	
	// AGREGAR EMOTICONO O CENSURA
	public function addBadWord() {
		global $tsCore, $tsUser;
		
		if($tsUser->is_admod == 1) {
			$word = $tsCore->setSecure($_GET['word']);
			$swop = $tsCore->setSecure($_GET['swop']);
			$method = $tsCore->setSecure($_GET['method']);
			$type = $tsCore->setSecure($_GET['type']);
			$reason = 'chat';
			$date = time();
			
			$query = db_exec(array(__FILE__, __LINE__), 'query', "INSERT INTO w_badwords (word, swop, method, type, author, reason, date) VALUES ('{$word}', '{$swop}', '{$method}', '{$type}', '{$tsUser->uid}', '{$reason}', '{$date}')");
			$data = array('error' => true, 'message' => 'Se añadió el emoticono/censura correctamente.');
		}else {
			$data = array('error' => true, 'message' => 'No tienes permiso para realizar esta acción.');
		}
		
		return json_encode($data);
	}
	
	// OBTENER MENSAJES
	public function getMessages() {
		global $tsCore;
		
		$query = db_exec(array(__FILE__, __LINE__), 'query', 'SELECT msg_id, msg_user, msg_text, msg_date, user_name, rango_id, r_color FROM c_chat_messages LEFT JOIN u_miembros ON msg_user = user_id LEFT JOIN u_rangos ON user_rango = rango_id ORDER BY msg_id ASC');
		while($row = db_exec('fetch_array', $query)){
			$row['msg_text'] = $tsCore->parseBadWords($this->parseSmiles($row['msg_text']));
			if(date('d', $row['msg_date']) == date('d', time())) $row['msg_date'] = $this->chatDate($row['msg_date'], 2);
			else $row['msg_date'] = $this->chatDate($row['msg_date']);
			$data[] = $row;
		}
		
		return $data;
	}
	
	// CONTAR MENSAJES
	public function countMessages() {
		$query = db_exec(array(__FILE__, __LINE__), 'query', 'SELECT * FROM c_chat_messages');
		$count = db_exec('num_rows', $query);
		$data = array('error' => false, 'count' => $count);
		if($count >= 60) {
			$query_delete = db_exec(array(__FILE__, __LINE__), 'query', 'SELECT * FROM c_chat_messages ORDER BY msg_id ASC LIMIT 10');
			while($delete = db_exec('fetch_array', $query_delete)){
				db_exec(array(__FILE__, __LINE__), 'query', 'DELETE FROM c_chat_messages WHERE msg_id = "'.$delete['msg_id'].'"');
			}
		}
		return json_encode($data);
	}
	
	// BORRAR MENSAJE
	public function deleteMessage() {
		global $tsCore, $tsUser;
		
		if($tsUser->is_admod) {
			$type = $tsCore->setSecure($_GET['type']);
			
			if($type == 'byMsg') {
				$id = $tsCore->setSecure($_GET['id']);
				db_exec(array(__FILE__, __LINE__), 'query', "DELETE FROM c_chat_messages WHERE msg_id = '{$id}'");
				$message = 'El mensaje ha sido eliminado.';
			}elseif($type == 'byUser') {
				$user = $tsCore->setSecure($_GET['id']);
				db_exec(array(__FILE__, __LINE__), 'query', "DELETE FROM c_chat_messages WHERE msg_user = '{$user}'");
				$message = 'Los mensajes del usuario han sido eliminados.';
			}elseif($type == 'all') {
				db_exec(array(__FILE__, __LINE__), 'query', "DELETE FROM c_chat_messages");
				$message = 'Todos los mensajes fueron eliminados.';
			}
			$data = array('error' => false, 'message' => $message);
		}else {
			$data = array('error' => true, 'message' => 'No tienes permiso para realizar esta acción.');
		}
		
		return json_encode($data);
	}
	
	// BANEAR USUARIO
	public function banUser() {
		global $tsCore, $tsUser;
		
		$time = time();

		$nick = $tsCore->setSecure($_GET['user']);
		$user = $tsUser->getUserID($nick);
		$type = $tsCore->setSecure($_GET['type']);
		if(empty($type)) $type = 'new';
		
		$check = db_exec(array(__FILE__, __LINE__), 'query', "SELECT user_rango FROM u_miembros WHERE user_id = '{$user}'");
		$rango = db_exec('fetch_array', $check);
		$exist = db_exec('num_rows', $check);
		
		if($exist != 0) {
			if($tsUser->is_admod && $tsUser->info.user_rango != $rango['user_rango']) {
				$day = $tsCore->setSecure($_GET['day']); $month = $tsCore->setSecure($_GET['month']); $year = $tsCore->setSecure($_GET['year']);
				$hour = $tsCore->setSecure($_GET['hour']); $minute = $tsCore->setSecure($_GET['minute']);
				$expire = mktime($hour, $minute, 0, $month, $day, $year);
				
				$checkBan = db_exec(array(__FILE__, __LINE__), 'query', "SELECT ban_expire FROM c_chat_blacklist WHERE ban_user = '{$user}' LIMIT 1");
				$checkCount = db_exec('num_rows', $checkBan);
				$checkBan = db_exec('fetch_array', $checkBan);
				
				if(time() > $checkBan['ban_expire'] || $type == 'edit' || $type == 'delete') {
					db_exec(array(__FILE__, __LINE__), 'query', "DELETE FROM c_chat_blacklist WHERE ban_user = '{$user}'");
					if($type != 'delete') $checkCount = 0;
				}
				
				if($checkCount == 0) {
					db_exec(array(__FILE__, __LINE__), 'query', "INSERT INTO c_chat_blacklist (ban_user, ban_expire, ban_date) VALUES ('{$user}', '{$expire}', '{$time}')");
					$data = array('error' => false, 'message' => $nick.' ha sido baneado hasta el '.$this->chatDate($expire));
					if($type == 'edit') $data['message'] = 'La fecha ha sido modificada correctamente.';
				}else {
					$data = array('error' => false, 'message' => $nick.' ya está baneado hasta el '.$this->chatDate($checkBan['ban_expire']));
					if($type == 'delete') $data['message'] = $nick.' ya no está baneado.';
				}
			}else {
				$data = array('error' => true, 'message' => 'No tienes permiso para realizar esta acción.');
			}
		}else {
			$data = array('error' => true, 'message' => 'El usuario "'.$nick.'" no existe.');
		}
		
		return json_encode($data);
	}
	
	// MOSTRAR USUARIOS BANEADOS
	public function banList() {
		global $tsUser;
		
		if($tsUser->is_admod) {
			$query = db_exec(array(__FILE__, __LINE__), 'query', 'SELECT ban_id, ban_user, ban_expire, ban_date, user_name FROM c_chat_blacklist LEFT JOIN u_miembros ON ban_user = user_id');
			while($row = db_exec('fetch_array', $query)){
				if(time() > $row['ban_expire']) {
					db_exec(array(__FILE__, __LINE__), 'query', "DELETE FROM c_chat_blacklist WHERE ban_user = '{$row['ban_user']}'");
					unset($row);
				}else {
					$row['ban_expire'] = $this->chatDate($row['ban_expire']);
					$row['ban_date'] = $this->chatDate($row['ban_date']);
					$data[] = $row;
				}
			}
		}else {
			$data = 'not';
		}
		
		return $data;
	}
	
	// LISTAR EMOTICONOS
	public function getEmotes() {
		$query = db_exec(array(__FILE__, __LINE__), 'query', "SELECT word, swop FROM w_badwords WHERE type = 1");
		
		return result_array($query);
	}
	
	// MOSTRAR USUARIOS CONECTADOS
	public function getOnline() {
		$online = time() - (5 * 60);
		$query = db_exec(array(__FILE__, __LINE__), 'query', "SELECT user_name FROM u_miembros WHERE user_chat >= {$online}");
		
		return result_array($query);
	}
}
?>