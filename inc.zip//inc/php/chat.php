<?php
/**
 * Chat
 *
 * @name    chat.php
 * @author  RhuanCarlos
*/

/**********************************\

*	(VARIABLES POR DEFAULT)		*

\*********************************/

	$tsPage = "chat";	// tsPage.tpl -> PLANTILLA PARA MOSTRAR CON ESTE ARCHIVO

	$tsLevel = 2;		// NIVEL DE ACCESO A ESTA PÁGINA. => VER FAQs (que no existen)

	$tsAjax = empty($_GET['ajax']) ? 0 : 1; // ¿LA RESPUESTA SERÁ AJAX?
	
	$tsContinue = true;	// CONTINUAR EL SCRIPT
	
	error_reporting(0);
	
/*++++++++ = ++++++++*/

	include "../../header.php"; // INCLUIR EL HEADER

	$tsTitle = $tsCore->settings['titulo'].' - '.$tsCore->settings['slogan']; 	// TÍTULO DE LA PÁGINA ACTUAL

/*++++++++ = ++++++++*/

	// VERIFICAMOS EL NIVEL DE ACCSESO ANTES CONFIGURADO
	$tsLevelMsg = $tsCore->setLevel($tsLevel, true);
	if($tsLevelMsg != 1){	
		$tsPage = 'aviso';
		$tsAjax = 0;
		$smarty->assign("tsAviso", $tsLevelMsg);
		//
		$tsContinue = false;
	}
	//
	if($tsContinue){
	
	/*++++++++ = ++++++++*/
	
		$smarty->assign("tsAction", $_GET['p']);

	}

if(empty($tsAjax)) {	// SI LA PETICIÓN SE HIZO POR AJAX DETENER EL SCRIPT Y NO MOSTRAR PLANTILLA, SI NO ENTONCES MOSTRARLA.

	$smarty->assign("tsTitle", $tsTitle);	// AGREGAR EL TÍULO DE LA PÁGINA ACTUAL

	/*++++++++ = ++++++++*/
	include("../../footer.php");
	/*++++++++ = ++++++++*/
}
?>