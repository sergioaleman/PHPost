<?php if ( ! defined('TS_HEADER')) exit('No se permite el acceso directo al script');
/**
 * Controlador AJAX
 *
 * @name    ajax.chat.php
 * @author  RhuanCarlos
*/
/**********************************\

*	(VARIABLES POR DEFAULT)		*

\*********************************/

	// NIVELES DE ACCESO Y PLANTILLAS DE CADA ACCIÓN
	$files = array(
		'chat-send' => array('n' => 2, 'p' => ''),
		'chat-delete' => array('n' => 2, 'p' => ''),
		'chat-count' => array('n' => 2, 'p' => ''),
		'chat-ban' => array('n' => 2, 'p' => ''),
		'chat-badword' => array('n' => 2, 'p' => ''),
		'chat-load' => array('n' => 2, 'p' => 'load'),
		'chat-banlist' => array('n' => 2, 'p' => 'banlist'),
		'chat-online' => array('n' => 2, 'p' => 'online'),
		'chat-emotes' => array('n' => 2, 'p' => 'emotes'),
	);

/**********************************\

* (VARIABLES LOCALES ESTE ARCHIVO)	*

\*********************************/

	// REDEFINIR VARIABLES
	$tsPage = 'php_files/p.chat.'.$files[$action]['p'];
	$tsLevel = $files[$action]['n'];
	$tsAjax = empty($files[$action]['p']) ? 1 : 0;

/**********************************\

*	(INSTRUCCIONES DE CODIGO)		*

\*********************************/
	
	// DEPENDE EL NIVEL
	$tsLevelMsg = $tsCore->setLevel($tsLevel, true);
	if($tsLevelMsg != 1) { echo '0: '.$tsLevelMsg; die();}
	
	// INCLUIR LA CLASE DEL CHAT
	require('../class/c.chat.php');
	$tsChat = new tsChat();
	
	// DOCTYPE JAVASCRIPT
	header("Content-type: text/javascript");
	
	// CODIGO
	switch($action){
		case 'chat-send':
			echo $tsChat->sendMessage();
		break;
		case 'chat-delete':
			echo $tsChat->deleteMessage();
		break;
		case 'chat-count':
			echo $tsChat->countMessages();
		break;
		case 'chat-ban':
			echo $tsChat->banUser();
		break;
		case 'chat-badword':
			echo $tsChat->addBadWord();
		break;
		case 'chat-load':
			$smarty->assign('tsChatMessages', $tsChat->getMessages());
		break;
		case 'chat-banlist':
			$smarty->assign('tsChatBanList', $tsChat->banList());
		break;
		case 'chat-online':
			$smarty->assign('tsChatOnline', $tsChat->getOnline());
		break;
		case 'chat-emotes':
			$smarty->assign('tsChatEmotes', $tsChat->getEmotes());
		break;
	}
?>