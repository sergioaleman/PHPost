<?php 
if ( ! defined('TS_HEADER')) exit('No se permite el acceso directo al script');
/**
 * Controlador AJAX
 *
 * @name    ajax.login.php
 * @author  PHPost Team
*/
/**********************************\

*	(VARIABLES POR DEFAULT)		*

\*********************************/

	// NIVELES DE ACCESO Y PLANTILLAS DE CADA ACCI�N
	$files = array(
		'contacto-send' => array('n' => 2, 'p' => ''),
	);

/**********************************\

* (VARIABLES LOCALES ESTE ARCHIVO)	*

\*********************************/

	// REDEFINIR VARIABLES
	$tsPage = 'php_files/p.contacto.'.$files[$action]['p'];
	$tsLevel = $files[$action]['n'];
	$tsAjax = empty($files[$action]['p']) ? 2 : 0;

/**********************************\

*	(INSTRUCCIONES DE CODIGO)		*

\*********************************/
	
	// DEPENDE EL NIVEL
	$tsLevelMsg = $tsCore->setLevel($tsLevel, true);
	if($tsLevelMsg != 2) { echo '0: '.$tsLevelMsg; die();}
	// CODIGO
	switch($action){
		case 'contacto-send':
			//<---		
			//
			$to = $tsCore->settings['email'];
			$email = $tsUser->info['user_email'];	
			$alert = ""; 
			$to = trim($to);
			$subject = trim($_POST['subject']);
			$message = trim($_POST['message']);
			$subject = $tsCore->setSecure($_POST['subject']);
			$message = $tsCore->setSecure($_POST['message']);
			$email = trim($email);
			if(empty($to) || empty($subject) || empty($message))
				$alert = '<div class="mensajes error">Error al enviar su mensaje...</div>';
			else if (!filter_var($email, FILTER_VALIDATE_EMAIL))
				$alert = '<div class="mensajes error">Error al enviar el formulario</div>';
			else if($to == $email)
				$alert = '<div class="mensajes error">No puedes enviarte una consulta a ti mismo!</div>';
			else
				enviar_correo($to,$subject,$tsTitle."\n\n".$email." envia la consulta:\n\n".$message);
			echo $alert;
			//--->
		break;
	}
	
function enviar_correo($to,$subject,$message)
{
	global $alert;
	mail($to, $subject, $message);
	$alert = '<div class="mensajes ok">Su consulta ha sido enviada correctamente, en breve le contactaremos a su correo ingresado con una respuesta!</div>';
}