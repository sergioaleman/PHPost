<?php 
/**
 * Language file
 *
 * @name    admin.lang.php
 * @author  PHPost Team
*/

$lang['menu'] = "Menú";
$lang['general'] = "General";
$lang['admin_center'] = "Centro de Administración";
$lang['admin_support'] = "Soporte y Créditos";
$lang['admin_config'] = "Configuración";
$lang['config'] = "Configuración de PHPost";
$lang['admin_styles'] = "Temas y apariencia";
$lang['admin_notices'] = "Noticias";
$lang['admin_ads'] = "Publicidad";
$lang['core_control'] = "Control de PHPost";
$lang['admin_medals'] = "Medallas";
$lang['admin_afiliate'] = "Afiliados";
$lang['admin_stats'] = "Estadísticas";
$lang['admin_bans'] = "Bloqueos";
$lang['admin_bad_words'] = "Palabras Censuras";
$lang['content_control'] = "Control de Contenido";
$lang['admin_posts'] = "Todos los Mensajes";
$lang['admin_photos'] = "Todas las Fotos";
$lang['admin_cats'] = "Categorías";
$lang['user_control'] = "Control de Usuarios";
$lang['admin_users'] = "Todos los Usuarios";
$lang['admin_sesions'] = "Sesiones";
$lang['admin_nick_change'] = "Cambios de Nicks";
$lang['admin_user_rank'] = "Rangos de Usuarios";
// Welcome Module.
$lang['admin_welcome'] = "Bienvenido(a),";
$lang['admin_welcome_txt'] = 'Este es tu "Centro de Administración de PHPost". Aquí puedes modificar la configuración de tu web, modificar usuarios, modificar mensajes, y muchas otras cosas.<br />Si tienes algun problema, por favor revisa la página de "Soporte y Créditos".  Si esa información no te sirve, puedes <a href="http://phpost.es/" target="_blank">visitarnos para solicitar ayuda</a> acerca de tu problema.';
$lang['admin_phpost_notices'] = "PHPost en directo";
$lang['admin_loading'] = "Cargando...";
$lang['admin_brand'] = "PHPost Cerberus";
$lang['admin_brand_version'] = "Versión instalada";
$lang['admin_admins'] = "Administradores";
$lang['admin_install'] = "Instalaciones";
$lang['admin_installed'] = "Fundación";
$lang['admin_updated'] = "Actualizado";
$lang['admin_tsinfo'] = "Información de versiones: ";
$lang['admin_tsinfo_core'] = "Versión de PHPost: ";
$lang['admin_tsinfo_php'] = "Versión de PHP: ";
$lang['admin_tsinfo_sql'] = "Versión de MySQL: ";
$lang['admin_tsinfo_host'] = "Versión del Servidor: ";
$lang['admin_tsinfo_gd'] = "Versión de GD: ";
$lang['admin_tsinfo_credits'] = "Créditos: ";
$lang['admin_tsinfo_credits_txt'] = 'La primera versión del script fue desarrollada por <a href="javascript:void(0);">JNeutron</a>. El resto de versiones se mantiene por <a href="https://phpost.es">PHPost en Español</a> y la participaci&oacute;n de los usuarios de la <a href="https://phpost.es">comunidad</a>.';
$lang['admin_tsinfo_copyright'] = "Derechos de autor: ";
$lang['admin_tsinfo_copyright_txt'] = 'Es de vital importancia recordar que el diseño y esquema de <b>PHPost</b> fueron <b>BASADOS</b> en la popular página <a href="https://www.taringa.net" target="_blank">Taringa!</a>, cuyos créditos y derechos de autor no pretenden ser adueñados por <a href="https://phpost.es">PHPost</a> ni ningún desarrollador. Dichos diseños y esquemas han sido adoptados a <b>PHPost</b> con fines meramente <b>EDUCATIVOS</b> y no se pretende <b>LUCRAR</b> con los mismos. Por ello, todas las imágenes, diseños y logos pertenecen a sus respectivos creadores. De ninguna manera hay contenido total sino parcial de el diseño y esquema que han sido creados a partir de cero y únicamente basados en el diseño original de taringa. Los derechos a sus respectivos creadores.';
