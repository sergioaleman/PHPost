<?php 
/**
 * Language file
 *
 * @name    posts.lang.php
 * @author  PHPost Team
*/

$lang['brand'] = "PHPost Cerberus";
$lang['stats'] = "Estadísticas";
$lang['max_online'] = "Max. en línea:";
$lang['online'] = "Conectados";
$lang['users'] = "Miembros";
$lang['comments'] = "Comentarios";
$lang['posts'] = "Mensajes";
$lang['photos'] = "Fotos";
$lang['photos_comments'] = "Comentarios en fotos";