<?php 
/**
 * Language file
 *
 * @name    portal.lang.php
 * @author  PHPost Team
*/

$lang['brand'] = "PHPost Cerberus";
$lang['welcome'] = "Bienvenido";
$lang['notices'] = "Noticias";
$lang['activity'] = "Actividad";
$lang['posts'] = "Mensajes";
$lang['favorites'] = "Favoritos";
$lang['notifications'] = "Notificaciones";
$lang['new_pms'] = "Mensajes nuevos";
$lang['add_post'] = "Agregar post";
$lang['add_photo'] = "Agregar foto";
$lang['edit_account'] = "Editar mi cuenta";
$lang['logout'] = "Cerrar Sesión";
$lang['stats'] = "Estadísticas";
$lang['max_online'] = "Max. en línea:";
$lang['online'] = "Conectados";
$lang['users'] = "Miembros";
$lang['comments'] = "Comentarios";
$lang['photos'] = "Fotos";
$lang['photos_comments'] = "Comentarios en fotos";