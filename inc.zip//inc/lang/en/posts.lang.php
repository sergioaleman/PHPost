<?php 
/**
 * Language file
 *
 * @name    posts.lang.php
 * @author  PHPost Team
*/

$lang['brand'] = "PHPost Cerberus";
$lang['stats'] = "Stats";
$lang['max_online'] = "Max. online:";
$lang['online'] = "Online";
$lang['users'] = "Members";
$lang['comments'] = "Comments";
$lang['posts'] = "Posts";
$lang['photos'] = "Photos";
$lang['photos_comments'] = "Comments in photos";