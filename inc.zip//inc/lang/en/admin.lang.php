<?php 
/**
 * Language file
 *
 * @name    admin.lang.php
 * @author  PHPost Team
*/

$lang['menu'] = "Menu";
$lang['general'] = "General";
$lang['admin_center'] = "Admin Control Panel";
$lang['admin_support'] = "Support and Credits";
$lang['admin_config'] = "Settings";
$lang['config'] = "PHPost Settings";
$lang['admin_styles'] = "Skins and Apareance";
$lang['admin_notices'] = "Notices";
$lang['admin_ads'] = "Ads";
$lang['core_control'] = "PHPost Control";
$lang['admin_medals'] = "Awards";
$lang['admin_afiliate'] = "Afiliates";
$lang['admin_stats'] = "Stats";
$lang['admin_bans'] = "Bans";
$lang['admin_bad_words'] = "Censored Words";
$lang['content_control'] = "Content Control";
$lang['admin_posts'] = "All Posts";
$lang['admin_photos'] = "All Photos";
$lang['admin_cats'] = "Categories";
$lang['user_control'] = "Users Control Panel";
$lang['admin_users'] = "All Users";
$lang['admin_sesions'] = "Sessions";
$lang['admin_nick_change'] = "Nicks Change";
$lang['admin_user_rank'] = "Users Ranks";
// Welcome Module.
$lang['admin_welcome'] = "Welcome,";
$lang['admin_welcome_txt'] = 'This is your " Admin Control Panel of PHPost". In here you can change and configure your web settings, modify users, modify posts, and much more.<br />If you have some issue, please review the "Support and Credits" page.  If that information does not serve, you can go to <a href="http://phpost.es/" target="_blank">here to ask for support</a> abbout your issue.';
$lang['admin_phpost_notices'] = "PHPost Live";
$lang['admin_loading'] = "Loading...";
$lang['admin_brand'] = "PHPost Cerberus";
$lang['admin_brand_version'] = "Installed Version";
$lang['admin_admins'] = "Administrators";
$lang['admin_install'] = "Installations";
$lang['admin_installed'] = "Foundation";
$lang['admin_updated'] = "Upgrade";
$lang['admin_tsinfo'] = "Versions Information: ";
$lang['admin_tsinfo_core'] = "PHPost Version: ";
$lang['admin_tsinfo_php'] = "PHP Version: ";
$lang['admin_tsinfo_sql'] = "MySQL Version: ";
$lang['admin_tsinfo_host'] = "Server Version: ";
$lang['admin_tsinfo_gd'] = "GD Version: ";
$lang['admin_tsinfo_credits'] = "Credits: ";
$lang['admin_tsinfo_credits_txt'] = 'The first script version was developed by <a href="javascript:void(0);">JNeutron</a>. And the current and next versions were mantained by <a href="https://phpost.es">Spanish PHPost</a> and users participation on our <a href="https://phpost.es">community</a>.';
$lang['admin_tsinfo_copyright'] = "Author copyright: ";
$lang['admin_tsinfo_copyright_txt'] = 'It is very importar to remember that this design and scheme of <b>PHPost</b> were <b>BASSED</b> on the popular page <a href="https://www.taringa.net" target="_blank">Taringa!</a>, whose credits and copyrights are not intended to be owned by <a href="https://phpost.es">PHPost</a> and neither their developers. Said designs and schemes have been adopted to <b>PHPost</b> for merely <b>EDUCATIONAL</b> purposes and it is not intended to get any <b>PROFIT</b> with the same. Therefore, all images, designs and logos belong to their respective creators. In no way is there total content but partial content of the design and scheme that have been created from scratch and only based on the original design of taringa. The rights to their respective owners.';
