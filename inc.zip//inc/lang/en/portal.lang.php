<?php 
/**
 * Language file
 *
 * @name    portal.lang.php
 * @author  PHPost Team
*/

$lang['brand'] = "PHPost Cerberus";
$lang['welcome'] = "Welcome";
$lang['notices'] = "Notices";
$lang['activity'] = "Activity";
$lang['posts'] = "Posts";
$lang['favorites'] = "Favorites";
$lang['notifications'] = "Notifications";
$lang['new_pms'] = "New Posts";
$lang['add_post'] = "Add Post";
$lang['add_photo'] = "Add Photo";
$lang['edit_account'] = "Edit Account";
$lang['logout'] = "Logout";
$lang['stats'] = "Stats";
$lang['max_online'] = "Max. online:";
$lang['online'] = "Online";
$lang['users'] = "Members";
$lang['comments'] = "Comments";
$lang['photos'] = "Photos";
$lang['photos_comments'] = "Comments in photos";