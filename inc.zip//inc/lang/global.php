<?php 
/**
 * Language file
 *
 * @name    global.php
 * @author  PHPost Team
*/

$lang['brand'] = "PHPost Cerberus";
$lang['welcome'] = "Bienvenido";