{if $tsFile.data.f_ext == 'jpg' || $tsFile.data.f_ext == 'gif' || $tsFile.data.f_ext == 'png' || $tsFile.data.f_ext == 'bmp' || $tsFile.data.f_ext == 'mp3' || $tsFile.data.f_ext == 'mp4' || $tsFile.data.f_ext == 'avi' || $tsFile.data.f_ext == 'wmv' || $tsFile.data.f_ext == 'flv' || $tsFile.data.f_ext == 'mkv' || $tsFile.data.f_ext == 'mpg' || $tsFile.data.f_ext == '3gp' || $tsFile.data.f_ext == 'txt' || $tsFile.data.f_ext == 'pdf' || $tsFile.data.f_ext == 'swf'}
	
    {* IMAGENES *}
    
    {if $tsFile.data.f_ext == 'jpg' || $tsFile.data.f_ext == 'gif' || $tsFile.data.f_ext == 'png' || $tsFile.data.f_ext == 'bmp'}
    
    <img src="{$tsConfig.url}/files/{$tsFile.data.f_url}" style="max-width: 650px;" />
    
    {* MUSICA *}
    {elseif $tsFile.data.f_ext == 'mp3'}
    
    <span id="sound" style="display: none;">
    <marquee direction="left">{$tsFile.data.f_nombre}</marquee>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
    </span>            
    <audio src="{$tsConfig.url}/files/{$tsFile.data.f_url}" type="audio/mp3" controls="controls"  style="width: 650px;" onplay="$('#sound').slideDown();" onpause="$('#sound').slideUp();"></audio>
    
    {* VIDEO *}
    
    {elseif $tsFile.data.f_ext == 'mp4' || $tsFile.data.f_ext == 'avi' || $tsFile.data.f_ext == 'wmv' || $tsFile.data.f_ext == 'flv' || $tsFile.data.f_ext == 'mkv' || $tsFile.data.f_ext == 'mpg' || $tsFile.data.f_ext == '3gp'}
    
    <video controls="controls" src="{$tsConfig.url}/files/{$tsFile.data.f_url}" type="video/mp4" style="width: 650px;"></video>
    
    {* SWF *}
    
    {elseif $tsFile.data.f_ext == 'swf'}
    
    <object width="650" height="450">
        <param name="movie" id="movie" value="{$tsConfig.url}/files/{$tsFile.data.f_url}">
        <param name="quality" value="high">
        <embed src="{$tsConfig.url}/files/{$tsFile.data.f_url}" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="650" height="450"></embed>
    </object>
    
    {* TEXTOS *}
    
    {elseif $tsFile.data.f_ext == 'txt' || $tsFile.data.f_ext == 'pdf'}
    
    <embed class="Ftipo_text" src="{$tsConfig.url}/files/{$tsFile.data.f_url}" pluginspage="http://www.adobe.com/shockwave/download/"></embed>
    
    {/if}
    
{* SI NO SE CONOCE EL ARCHIVO *} 
   
{else}

<div class="File_format">
    <img src="{$tsConfig.images}/files/file2.png" />
    <span>{$tsFile.data.f_ext}</span>
</div> 
           
{/if}