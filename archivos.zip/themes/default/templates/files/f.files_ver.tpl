<div class="F_left">
	<div class="file_box">
        <h2 class="fb_title" style="text-align: center;"><span id="File_nombre">{$tsFile.data.f_nombre|truncate:75}</span>.{$tsFile.data.f_ext}<span id="File_Fav" {if $tsFile.mifav.act == 0}style="display: none;"{/if} class="fb_right qtip" title="Lo tienes en tus favoritos"><img src="{$tsConfig.images}/files/fav_true.png" style="margin-top: -3px;" /></span></h2>
        <div class="fb_cuerpo" style="padding-top: 15px;" align="center">
        	{if $tsFile.data.f_estado == 0}
            <div class="emptyData" id="File_deleted">Este archivo ha sido eliminado, puedes verlo porque eres {if $tsUser->is_admod == 1}administrador <br />Para eliminarlo definitivamente haz click <a onclick="adminborrar_file({$tsFile.data.file_id}, false);">aqui</a>{else}moderador{/if}.<br />Puedes reactivarlo <a onclick="reactivar_file({$tsFile.data.file_id})">Aqui</a></div>
            {/if}
            {* Previsualizar Archivo [Si se puede] *} 
    		{include file='files/f.files_ver_archivo.tpl'}
    		{* DETALLES *}
            <div class="File_info">Subido {$tsFile.data.f_fecha|fecha}&nbsp;&nbsp;&nbsp;Tamaño: {$tsFile.data.f_peso} {if $tsUser->is_admod == 1}IP: <a href="http://localhost/demo/moderacion/buscador/1/1/{$tsFile.data.f_ip}" class="geoip" target="_blank">{$tsFile.data.f_ip}</a>{/if}</div>
            <div style="margin: 15px 0;" align="center">
            	{if $tsFile.data.f_user != $tsUser->uid}                    
                    <input type="button" onclick="borrar_fav({$tsFile.mifav.fav_id}, false); return false;" class="Fbtn b_red btn_favoritfile" value="BORRAR FAVORITO" style="width: auto;margin-right: 15px;{if $tsFile.mifav.act == 1}display: inline-block;{else}display: none;{/if}" />
                    <input type="button" onclick="{if !$tsUser->is_member}registro_load_form(){else}favorit_file({$tsFile.data.file_id}){/if}" class="Fbtn b_blue btn_favoritfile" value="FAVORITOS" id="btn_favoritfile" style="width: auto;margin-right: 15px;{if $tsFile.mifav.act == 1}display: none;{else}display: inline-block{/if}">
                {/if}
                <input type="button" onclick="download_file({$tsFile.data.file_id})" class="Fbtn b_green" value="DESCARGAR" id="btn_downloadfile" style="width: auto;">
            </div>
        </div>
    </div>
    <br />
    <div style="overflow: hidden;">{include file='modules/m.global_ads_728.tpl'}</div>
    <br />
    {* Comentarios del archivo *}
    {include file='files/f.files_ver_comentarios.tpl'}
</div>
