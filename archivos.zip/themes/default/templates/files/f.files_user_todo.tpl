<div class="F_left dinamic">
   	 <div class="file_box">
        <h2 class="fb_title">Ultimos Archivos</h2>
    	<div class="fb_cuerpo" style="padding: 0px;overflow: hidden;">        
            
            {************** ARCHIVOS ***************}
            
            <div class="F_files">
                {foreach from=$tsLastFiles.data item=a}
                <div class="list_file" id="File_{$a.file_id}" {if $a.f_estado == 0}style="opacity: 0.5;" title="Este archivo est&aacute; desabilitado"{/if}>
                    <a href="{$tsConfig.url}/files/{$a.file_id}/{$a.f_nombre|seo}">
                    <div class="File_format">
                        <img src="{$tsConfig.images}/files/file.png" height="55"/>
                        <span>{$a.f_ext}</span>
                    </div>
                    </a>
                    <div class="F_info">
                        <a href="{$tsConfig.url}/files/{$a.file_id}/{$a.f_nombre|seo}" class=""><h2 id="File_nombre">{$a.f_nombre|truncate:75}</h2></a>
                        Subido {$a.f_fecha|fecha}
                        Tama&ntilde;o: <strong>{$a.f_peso}</strong>
                        Comentario: <strong>{$a.f_comentarios}  </strong>              
                        Archivo <span id="File_privado_{$a.file_id}">{if $a.f_privado == 1}Privado{else}P&uacute;blico{/if}</span><br />

                    </div>
                    <div class="F_descarga">
                        
                    </div>
                </div>
                {/foreach}
                {if $tsPages.pages > 0}
                <div class="F_pag" style="overflow: hidden; padding: 5px;">
                    {if $tsPages.prev > 0 && $tsPages.max == false}
                    <a href="#" onclick="last_files('{$tsPages.prev}'); return false" class="floatL Abtn b_blue">Anterior</a>
                    {/if}
                    {if $tsPages.next <= $tsPages.pages}
                    <a href="#" onclick="last_files('{$tsPages.next}'); return false" class="floatR Abtn b_blue">Siguiente</a>
                    {/if}
                </div>
                {/if}
            </div>
    	</div>
    </div>
    <br />
    <div style="overflow: hidden;">{include file='modules/m.global_ads_728.tpl'}</div>
    <br />
</div>