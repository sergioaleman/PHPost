<span id="sound" style="display: none;">
<marquee direction="left">{$tsFile.data.f_nombre}</marquee>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
</span>            
<audio src="{$tsConfig.url}/files/{$tsFile.data.f_url}" type="audio/mp3" controls="controls"  style="width: 650px;" onplay="$('#sound').slideDown();" onpause="$('#sound').slideUp();"></audio>