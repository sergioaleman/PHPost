<div class="F_right">
	<div class="file_box">
        <h2 class="fb_title" align="center">Uploader</h2>
    	<div class="fb_cuerpo" align="center" style="padding: 10px;">
            <div class="FA_avatar" style="margin: 0;">
                <a href="{$tsConfig.url}/perfil/{$filesUser.user_name}" title="{$filesUser.user_name}">
                    <img src="{$tsConfig.url}/files/avatar/{$filesUser.user_id}_120.jpg" alt="Autor del archivo" />
                    <span>{$filesUser.user_name}</span>
                </a>
            </div>
        </div>
	</div>
    <div id="form_upload" align="center">
        <form id="New_upload" method="post" enctype="multipart/form-data">
             <div id="Select_file">
                 <a href="javascript: void(0);"class="Fbtn b_green list_text">Seleccionar archivo
                 	<input type="file" name="archivo" id="New_file" />
                 </a>
                 <div class="result_text"></div>
             </div>
             <input type="submit" value="Subir archivo" id="start_upload" class="Fbtn b_blue" style="display: none;" />
         </form>
         <div id="progress">
            <div id="bar"></div>
            <div id="percent">0%</div >
        </div>            
        <div id="message"></div>
	</div>
    <div class="file_box">
        <h2 class="fb_title">Buscar archivos</h2>
    	<div class="fb_cuerpo" align="center" style="padding: 10px;">
        	<form action="javascript: file_search({$filesUser.user_id}, {$folderUser.fid})" name="f_search" method="post">
            <input type="text" id="F_search" title="Buscar en {if $tsUser->uid != $filesUser.user_id}los archivos de {$filesUser.user_name}{else}mis archivos{/if}" placeholder="Buscar archivos..." />
            <input type="submit" value="Buscar" class="Abtn b_blue" />
        </div>
	</div>
    {if $filesUser.user_id == $tsUser->uid}
    {if $folderUser.nombre}
    <center><a href="{$tsConfig.url}/files/{$filesUser.user_name}" class="Fbtn">MIS ARCHIVOS</a></center>
    <br />
    {else}
    <center><a href="#" onclick="new_folder(); return false;" class="Fbtn">CREAR CARPETA</a></center>
    {/if}
    <br />
    <div class="file_box" id="FA_seleccionados" style="display: none;">
    	<h2 class="fb_title">Seleccionados</h2>
        <div class="fb_cuerpo">
        <a class="Abtn b_green" onclick="check.todos(); return false;" href="#" title="Seleccionar todos los archivos">Todos</a>
        <a class="Abtn b_blue" onclick="check.cargar(); return false;" href="#" title="Mover archivos seleccionados">Mover</a>
        <a class="Abtn b_red" onclick="check.borrar(); return false;" href="#" title="Eliminar archivos seleccionados">Borrar</a>
        </div>
    </div>
    <div class="file_box">
        <h2 class="fb_title">Favoritos<span class="fb_right">{$filesUser.total_favs}</span></h2>
    	<div class="fb_cuerpo" style="padding: 0;">
        	{if $filesUser.total_favs > 0}
        	{foreach from=$filesUser.favoritos item=f}
            <div class="FF_list" {if $f.f_estado == 0}style="opacity: 0.5;" title="Este archivo est&aacute; desabilitado"{/if}>
            <a href="{$tsConfig.url}/perfil/{$f.user_name}" title="Subido por {$f.user_name}" class="floatL"><img src="{$tsConfig.url}/files/avatar/{$f.f_user}_50.jpg" height="30" width="30" /></a>
            <div class="FF_detalles">
            	<a href="{$tsConfig.url}/files/{$f.file_id}/{$f.f_seo}">{$f.f_nombre|truncate:45}.{$f.f_ext}</a>
            </div>
            </div>
            {/foreach}
            {else}
            <div class="emptyData">No tienes archivos favoritos.</div>
            {/if}
        </div>
	</div>
    {if $filesUser.total_favs > 0}
    <center><a href="{$tsConfig.url}/files/favoritos/" class="Fbtn b_green">VER FAVORITOS</a></center>
    {/if}
    <br />
    {/if}    
    <div class="file_box">
        <h2 class="fb_title">Comentarios recientes</h2>
    	<div class="fb_cuerpo" style="padding: 0;">
        	{if $getLastcom}
        	{foreach from=$getLastcom item=f}
            <div class="FF_list" {if $f.f_estado == 0}style="opacity: 0.5;" title="Este archivo est&aacute; desabilitado"{/if}>
            <a href="{$tsConfig.url}/perfil/{$f.user_name}" title="{$f.user_name}" class="floatL"><img src="{$tsConfig.url}/files/avatar/{$f.com_user}_50.jpg" height="30" width="30" /></a>
            <div class="FF_detalles">
            	<a href="{$tsConfig.url}/files/{$f.file_id}/{$f.f_nombre|seo}" title="{$f.com_fecha|hace}">{$f.f_nombre|truncate:45}.{$f.f_ext}</a>
            </div>
            </div>
            {/foreach}
            <span style="clear:both;"></span>
            {else}
            <div class="emptyData">No se han hecho comentarios a&uacute;n.</div>
            {/if}
        </div>
	</div>
    {include file='modules/m.global_ads_160.tpl'}
</div>