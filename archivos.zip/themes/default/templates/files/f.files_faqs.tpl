<div class="file_box">
    <h2 class="fb_title">FAQs para la secci&oacute;n de archivos de {$tsConfig.titulo}</h2>
    <div class="fb_cuerpo" style="padding: 10px;font-size: 13px;text-align: justify;">
        <div class="faqs_mapa">
            <ul>
            	<li><a href="javascript: $.scrollTo($('#aviso_de_copyright'), 500);">Aviso de Copyright</a>
                <li><a href="javascript: $.scrollTo($('#preguntas_frecuentes'), 500);">Preguntas frecuentes</a>
                    <ul>
                        <li><a href="javascript: $.scrollTo($('#faqs_1'), 500);">¿Qu&eacute; archivos puedo cargar y almacenar?</a></li>
                        <li><a href="javascript: $.scrollTo($('#faqs_2'), 500);">¿Cuantos archivos puedo subir y que tama&ntilde;o permite?</a></li>
                        <li><a href="javascript: $.scrollTo($('#faqs_3'), 500);">¿C&oacute;mo comparto mis archivos?</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        <hr />
        <div class="faqs_cont">
        <h2 id="aviso_de_copyright">Aviso de Copyright</h2>
		<p>{$tsConfig.titulo} respeta los derechos de propiedad de terceros y requiere que los usuarios del servicio de archivos de {$tsConfig.titulo} acepten a su vez las leyes respecto al copyright. Se proh&iacute;be estrictamente utilizar el servicio de archivos de {$tsConfig.titulo} para infringir dichos derechos de propiedad. No debes subir, descargar, compartir, mostrar, hacer streaming, distribuir, enviar por e-mail, enlazar, transmitir o proporcionar ning&uacute;n archivo que infrinja cualquier copyright o derecho de autor de cualquier persona o entidad.</p>
        <hr />
        <h2 id="faqs_1">¿Qu&eacute; archivos puedo cargar y almacenar?</h2>
        <p>Puedes subir todos los archivos que cumplen con nuestros T&eacute;rminos y Condiciones. Por favor no subir cualquier material pornogr&aacute;fico, violento o derechos de autor. Aceptamos todos los tipos de archivo para la carga.</p>
        <h2 id="faqs_2">¿Cuantos archivos puedo subir y que tama&ntilde;o permite?</h2>
        <p>{$tsConfig.titulo} te permite subir todos los archivos que desees pero solo uno a la vez. Para cada archivo tiene un l&iacute;mite de subida de hasta {$tsConfig.c_max_upload}Mb.</p>
        <h2 id="faqs_3">¿C&oacute;mo comparto mis archivos?</h2>
        <strong>Para los archivos:</strong>
        <ul>
            <li>&bull; Al subir un archivo este ser&aacute; p&uacute;blico para todos los usuarios registrados en {$tsConfig.titulo}, sin embargo puedes cambiar esta configuraci&oacute;n para cada archivo sea privado/p&uacute;blico.</li>
            <li>&bull; Mientras el archivo sea p&uacute;blico, podr&aacute; ser visto y descargado por cualquier usuario registrado en {$tsConfig.titulo}.</li>
        </ul>
        <strong>Para las carpetas:</strong>
        <ul>
            <li>&bull; Al crear una carpeta o folder de archivos esta ser&aacute; privada y solo t&uacute; podras acceder a sus archivos, sin embargo puedes cambiar esta configuraci&oacute;n para cada carpeta sea privada/p&uacute;blica.</li>
            <li>&bull; Mientras la carpeta sea p&uacute;blica, podr&aacute; ser vista junto con su contenido por cualquier usuario registrado en {$tsConfig.titulo} cuando visite tu p&aacute;gina principal de archivos.</li>
            <li>&bull; Los archivos dentro de las carpetas privadas no ser&aacute;n visibles por otros usuarios en esa ubicaci&oacute;n pero si alguno de estos archivos es p&uacute;blico podr&aacute;n acceder otros usuarios a quienes se les haya compartido el enlace de descarga del mismo.</li>
            <li>&bull; Al cambiar el estado de privacidad de una carpeta, los archivos que esten dentro de ella (si hay) cambiaran tambien su configuracion deacuerdo al estado al que se le asigne a la carpeta.</li>
        </ul>
        <br />
        </div>
    </div>
</div>