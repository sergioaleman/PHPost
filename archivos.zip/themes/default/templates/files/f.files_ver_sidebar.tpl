<div class="F_right">
	<div class="file_box">
        <h2 class="fb_title" align="center">Uploader</h2>
    	<div class="fb_cuerpo" align="center" style="padding: 10px;">
            <div class="FA_avatar">
                <a href="{$tsConfig.url}/perfil/{$tsFile.data.user_name}" title="{$tsFile.data.user_name}">
                    <img src="{$tsConfig.url}/files/avatar/{$tsFile.data.f_user}_120.jpg" alt="Autor del archivo" />
                    <span>{$tsFile.data.user_name}</span>
                </a>
            </div>
        <a href="{$tsConfig.url}/files/{$tsFile.data.user_name}" class="Abtn b_blue">Ver m&aacute;s archivos</a>
        </div>
	</div>
    {if $tsUser->is_member}
   <div id="form_upload" align="center">
        <form id="New_upload" method="post" enctype="multipart/form-data">
             <div id="Select_file">
                 <a href="javascript: void(0);"class="Fbtn b_green list_text">Seleccionar archivo
                 	<input type="file" name="archivo" id="New_file" />
                 </a>
                 <div class="result_text"></div>
             </div>
             <input type="submit" value="Subir archivo" id="start_upload" class="Fbtn b_blue" style="display: none;" />
         </form>
         <div id="progress">
            <div id="bar"></div>
            <div id="percent">0%</div >
        </div>            
        <div id="message"></div>
	</div>
    {/if}
    {* HERRAMIENTAS *}
    {if $tsFile.data.f_user == $tsUser->uid || $tsUser->is_admod}
    <div class="file_box">
        <h2 class="fb_title" onclick="FB_herramientas();" style="cursor: pointer;">Herramientas<span class="fb_right" id="FB_cross" style="width: 9px;">+</span></h2>
    </div>
    <div id="FB_herramientas" style="margin-bottom: 15px; display: none;" align="center">
        <a href="#" onclick="editar_nombre({$tsFile.data.file_id}, '{$tsFile.data.f_nombre}', false); return false;" class="Abtn b_blue">Editar</a>
        <a href="#" class="Abtn b_green qtip File_privado_b{$tsFile.data.file_id}" {if $tsFile.data.f_privado == 1}style="display: none;"{/if} onclick="file_private({$tsFile.data.file_id}, 1); return false;" title="Cambiar a privado">Privado</a>
        <a href="#" class="Abtn b_green qtip File_privado_b{$tsFile.data.file_id}" {if $tsFile.data.f_privado == 0}style="display: none;"{/if} onclick="file_private({$tsFile.data.file_id}, 0); return false;" title="Cambiar a p&uacute;blico">P&uacute;blico</a>
        <a href="#" onclick="borrar_file({$tsFile.data.file_id}, false); return false;" class="Abtn b_red">Borrar</a>
        <input type="hidden" id="del_file" value="true" />
    </div>
    {/if}
    
    {* USUARIOS QUE HAN DESCARGADO EL ARCHIVO *}
    <div class="file_box">
        <h2 class="fb_title">Total descargas<span class="fb_right">{$tsFile.data.f_descargas}</span></h2>
        {if $tsFile.users}
        <div class="fb_cuerpo" style="padding-bottom: 1px;">
            {foreach from=$tsFile.users item=a}
            <a href="{$tsConfig.url}/perfil/{$a.user_name}" class="F_miniavatar">
                <img src="{$tsConfig.url}/files/avatar/{$a.d_user}_50.jpg" class="qtip" title="{if $a.d_total > 1}{$a.d_total} veces - {/if}{$a.d_fecha|fecha}" />
            </a>
            {/foreach}
        </div>
        {else}
        <div class="fb_cuerpo" style="padding: 0;"><div class="emptyData" style="border: 0;">Nadie ha descargado este archivo</div></div>
        {/if}
    </div>
    
    {* USUARIOS QUE HAN AGREGADO A FAVORITOS *}
    <div class="file_box">
        <h2 class="fb_title">Favoritos<span class="fb_right">{$tsFile.total.favoritos}</span></h2>
        {if $tsFile.total.favoritos > 0}
        <div class="fb_cuerpo" style="padding-bottom: 1px;">
            {foreach from=$tsFile.favoritos item=a}
            <a href="{$tsConfig.url}/perfil/{$a.user_name}" class="F_miniavatar" >
                <img src="{$tsConfig.url}/files/avatar/{$a.fav_user}_50.jpg" class="qtip" title="{$a.fav_fecha|fecha}" />
            </a>
            {/foreach}
        </div>
        {else}
        <div class="fb_cuerpo" style="padding: 0;"><div class="emptyData" style="border: 0;">Nadie ha agregado a favoritos</div></div>
        {/if}
    </div><br />
    {include file='modules/m.global_ads_160.tpl'}
</div>