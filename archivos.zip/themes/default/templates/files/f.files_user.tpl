<div class="F_left">
    <div class="file_box" id="SearchResult" style="display: none;"></div>
    <div class="file_box">
        <h2 class="fb_title">
        {if $tsUser->uid == $filesUser.user_id}Mis archivos{else}Archivos subidos por {$filesUser.user_name}{/if} {$folderUser.nombre}
        <span class="fb_right" id="Files_total">{if $filesUser.pages.limit+20|number_format > $filesUser.total}{$filesUser.total+0}{else}{$filesUser.pages.limit+20|number_format}{/if} de {$filesUser.total+0}</span>
       	<span style="float: right;margin-right: 15px;cursor:pointer;" onclick="$('.fb_extras').slideToggle('fast')">Ordenar</span>
        </h2>
        <div class="fb_extras">
        	<a href="{$tsConfig.url}/files/{$filesUser.user_name}?o=fecha&f=d" class="{if $filesUser.o=='fecha'}o_act{/if}">Fecha</a>
        	<a href="{$tsConfig.url}/files/{$filesUser.user_name}?o=nombre&f=a" class="{if $filesUser.o=='nombre'}o_act{/if}">Nombre</a>
        	<a href="{$tsConfig.url}/files/{$filesUser.user_name}?o=descargas&f=a" class="{if $filesUser.o=='descargas'}o_act{/if}">Descargas</a>
            <a href="{$tsConfig.url}/files/{$filesUser.user_name}?o=ext&f=a" class="{if $filesUser.o=='ext'}o_act{/if}">Tipo</a>
            {if $filesUser.f=='a'}
            <a href="{$tsConfig.url}/files/{$filesUser.user_name}?o={$filesUser.o}&f=d" class="floatR">Descendente</a>
            {elseif $filesUser.f=='d'}
            <a href="{$tsConfig.url}/files/{$filesUser.user_name}?o={$filesUser.o}&f=a" class="floatR">Ascendente</a>
            {/if}
        </div>
    	<div class="fb_cuerpo" style="padding: 0px;overflow: hidden;">        
        
            {if $filesUser.total > 0 || $folderUser.total > 0}
        
        	{************** CARPETAS ***************}
            
            {if $folderUser.data}
        	<div class="F_folders">
                {foreach from=$folderUser.data item=f}
                <div class="list_file" id="folderid_{$f.folder_id}">
                    <div class="File_format">
                        <a href="{$tsConfig.url}/files/{$filesUser.user_name}/{$f.folder_id}/{$f.folder_name|seo}"><img src="{$tsConfig.images}/files/folder.png" height="50"/></a>
                    </div>
                    <div class="F_info">
                        <a href="{$tsConfig.url}/files/{$filesUser.user_name}/{$f.folder_id}/{$f.folder_name|seo}"><h2 id="Folder_name">{$f.folder_name}</h2></a>
                        {$f.folder_fecha|fecha}            
                        Carpeta <span id="Folder_privado_{$f.folder_id}">{if $f.folder_priv == 1}Privada{else}P&uacute;blica{/if}</span><br />
                        <a href="#" onclick="borrar_folder({$f.folder_id}); return false;" class="">Borrar</a> |
                        <a href="#" onclick="editar_folder({$f.folder_id}, '{$f.folder_name}'); return false;" class="">Editar nombre</a> |
                        <a href="#" class="qtip Folder_privado_{$f.folder_id}" {if $f.folder_priv == 1}style="display: none;"{/if} onclick="folder_private({$f.folder_id}, 1); return false;" title="Cambiar a privada">Privada</a>
                        <a href="#" class="qtip Folder_privado_{$f.folder_id}" {if $f.folder_priv == 0}style="display: none;"{/if} onclick="folder_private({$f.folder_id}, 0); return false;" title="Cambiar a p&uacute;blica">P&uacute;blica</a>
                    </div>
                </div>
                {/foreach}                
            </div>
            {/if}
            <div id="F_newfolder"></div>
            
            {************** ARCHIVOS ***************}
            
            <div class="F_files">
                {foreach from=$filesUser.data item=a}
                <div class="list_file" id="File_{$a.file_id}" {if $a.f_estado == 0}style="opacity: 0.5;" title="Este archivo est&aacute; desabilitado"{/if}>
                    <a href="{$tsConfig.url}/files/{$a.file_id}/{$a.f_nombre|seo}">
                    <div class="File_format">
                        <img src="{$tsConfig.images}/files/file.png" height="55"/>
                        <span>{$a.f_ext}</span>
                    </div>
                    </a>
                    <div class="F_info">
                        <a href="{$tsConfig.url}/files/{$a.file_id}/{$a.f_nombre|seo}" class=""><h2 class="File_nombre">{$a.f_nombre|truncate:75}</h2></a>
                        Subido {$a.f_fecha|fecha}
                        Tama&ntilde;o: <strong>{$a.f_peso}</strong>
                        Descargas: <strong>{$a.f_descargas}  </strong>              
                        Archivo <span id="File_privado_{$a.file_id}">{if $a.f_privado == 1}Privado{else}P&uacute;blico{/if}</span><br />
                        {if $tsUser->uid == $filesUser.user_id || $tsUser->is_admod}
                        <a href="#" onclick="download_file({$a.file_id}); return false;" class="">Descargar</a> |
                        <a href="#" onclick="borrar_file({$a.file_id}, false); return false;" class="">Borrar</a> |
                        {if $filesUser.user_id == $tsUser->uid}
                        <a href="#" onclick="folder.cargar({$a.file_id}); return false;" class="">Mover</a> |
                        {/if}
                        <a href="#" onclick="editar_nombre({$a.file_id}, '{$a.f_nombre}', false); return false;" class="">Editar nombre</a> |
                        <a href="#" class="qtip File_privado_b{$a.file_id}" {if $a.f_privado == 1}style="display: none;"{/if} onclick="file_private({$a.file_id}, 1); return false;" title="Cambiar a privado">Privado</a>
                        <a href="#" class="qtip File_privado_b{$a.file_id}" {if $a.f_privado == 0}style="display: none;"{/if} onclick="file_private({$a.file_id}, 0); return false;" title="Cambiar a p&uacute;blico">P&uacute;blico</a>
                        <input type="checkbox" name="file_id_box[]" value="{$a.file_id}" onclick="check.marcar();" class="floatR" />
                        {/if}
                    </div>
                </div>
                {/foreach}
				{if $filesUser.total > 20}
				<div class="F_pag" style="overflow: hidden; padding: 5px;">
					{if $filesUser.pages.prev}
					<a href="{$tsConfig.url}/files/{$filesUser.user_name}/pagina{$filesUser.pages.prev}{if $filesUser.o}?o={$filesUser.o}&f={$filesUser.f}{/if}" class="floatL Abtn b_blue">Anterior</a>
					{/if}
					{if $filesUser.pages.next}
					<a href="{$tsConfig.url}/files/{$filesUser.user_name}/pagina{$filesUser.pages.next}{if $filesUser.o}?o={$filesUser.o}&f={$filesUser.f}{/if}" class="floatR Abtn b_blue">Siguiente</a>
					{/if}
				</div>
				{/if}
            </div>
            {else}
            <div class="emptyData">{if $tsUser->uid == $filesUser.user_id}No has subido ning&uacute;n arhivo.{else}{$filesUser.user_name} no ha subido archivos.{/if}</div>
            {/if}
    	</div>
    </div>  
    
	
    {************** ULTIMOS PUBLICOS ***************}
	{if !$folderUser.nombre && $tsLastFiles.data}
    <div class="file_box">
        <h2 class="fb_title">Ultimos Archivos p&uacute;blicos</h2>
    	<div class="fb_cuerpo" style="padding: 0px;overflow: hidden;">            
            <div id="more_last_files" class="F_files">
                {include file='t.php_files/p.files.last-files.tpl'}
            </div>
    	</div>
    </div>
	{/if}
</div>