{include file='sections/main_header.tpl'}

<script type="text/javascript" src="{$tsConfig.js}/files.js"></script>
<script src="{$tsConfig.js}/jquery.form.js"></script>

{if $tsAction == 'new'}
	{include file='files/f.files_agregar.tpl'}
{elseif $tsAction == 'user'}
    {include file='files/f.files_user.tpl'}
    {include file='files/f.files_user_sidebar.tpl'}
{elseif $tsAction == 'ver'}
    {include file='files/f.files_ver.tpl'}
    {include file='files/f.files_ver_sidebar.tpl'}
{elseif $tsAction == 'favoritos'}
    {include file='files/f.files_fav.tpl'}
    {include file='files/f.files_fav_sidebar.tpl'}
{elseif $tsAction == 'faqs'}
	{include file='files/f.files_faqs.tpl'}
{/if}

<div align="center" style="opacity: 0.3;clear: both;font-size: 11px;">Secci&oacute;n de archivos creado por <a href="https://phpost.es/">Kmario19</a> para <a href="https://phpost.es/">PHPost</a></div>

{include file='sections/main_footer.tpl'}