{if $tsResult.data}
<h2 class="fb_title">Resultados de la busqueda para "{$tsResult.text}"<span class="fb_right" id="Files_total">{$tsResult.total}</span></h2>
<div class="fb_cuerpo" style="padding: 0px;overflow: hidden;">
    <div class="F_files">
        {foreach from=$tsResult.data item=a}
        <div class="list_file" id="File_{$a.file_id}">
            <a href="{$tsConfig.url}/files/{$a.file_id}/{$a.f_seo}">
            <div class="File_format">
                <img src="{$tsConfig.images}/files/file.png" height="55"/>
                <span>{$a.f_ext}</span>
            </div>
            </a>
            <div class="F_info">
                <a href="{$tsConfig.url}/files/{$a.file_id}/{$a.f_seo}" class=""><h2 id="File_nombre">{$a.f_nombre|truncate:75}</h2></a>
                Subido {$a.f_fecha|fecha}
                Tama&ntilde;o: <strong>{$a.f_peso}</strong>
                Descargas: <strong>{$a.f_descargas}  </strong>              
                Archivo <span id="File_privado_{$a.file_id}">{if $a.f_privado == 1}Privado{else}P&uacute;blico{/if}</span><br />
                {if $tsUser->uid == $filesUser.user_id || $tsUser->is_admod}
                <a href="#" onclick="download_file({$a.file_id}); return false;" class="">Descargar</a> |
                <a href="#" onclick="borrar_file({$a.file_id}, false); return false;" class="">Borrar</a> |
                {if $a.f_user == $tsUser->uid}
                <a href="#" onclick="folder.cargar({$a.file_id}); return false;" class="">Mover</a> |
                {/if}
                <a href="#" onclick="editar_nombre({$a.file_id}, '{$a.f_nombre}', false); return false;" class="">Editar nombre</a> |
                <a href="#" class="qtip File_privado_b{$a.file_id}" {if $a.f_privado == 1}style="display: none;"{/if} onclick="file_private({$a.file_id}, 1); return false;" title="Cambiar a privado">Privado</a>
                <a href="#" class="qtip File_privado_b{$a.file_id}" {if $a.f_privado == 0}style="display: none;"{/if} onclick="file_private({$a.file_id}, 0); return false;" title="Cambiar a p&uacute;blico">P&uacute;blico</a>
                {* ELIMINAR Y MOVER MULTIPLES ARCHIVOS EN DESARROLLO *}
                {* <input type="checkbox" name="{$a.file_id}" value="{$a.file_id}" onclick="check.marcar();" class="floatR" /> *}
                {/if}
            </div>
            <div class="F_descarga">
                
            </div>
        </div>
        {/foreach}
    </div>    
</div>
{else}
<div class="emptyData">No se encontraron resultados para "{$tsResult.text}" en esta ubicaci&oacute;n</div>
{/if}