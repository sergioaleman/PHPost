<div class="list_comfile" id="comfile_{$newCom.4}" style="border-top: 1px solid #ccc;">
    <div class="FA_mini floatL">
        <a href="{$tsConfig.url}/perfil/{$newCom.2}" title="Ver perfil de {$newCom.2}">
            <img src="{$tsConfig.url}/files/avatar/{$newCom.1}_50.jpg" />
        </a>
    </div>
    <div class="FA_udatos">
    	<strong><a href="{$tsConfig.url}/perfil/{$newCom.2}" title="Ver perfil de {$newCom.2}">{$newCom.2}</a></strong><span>{$newCom.3|fecha}</span>
    </div>
    <div class="FA_body">{$newCom.0|nl2br}</div>
    <a class="del_comfile" onclick="borrar_comfile({$newCom.4}, {$newCom.5}, false)">x</a>
</div>