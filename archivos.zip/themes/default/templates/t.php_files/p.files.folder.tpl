1:
<div class="list_file" id="folderid_{$folder.1}" style="border-bottom: 1px solid #ccc;">
    <div class="File_format">
        <a href="{$tsConfig.url}/files/{$filesUser.user_name}/{$folder.1}/{$folder.2}"><img src="{$tsConfig.images}/files/folder.png" height="50"/></a>
    </div>
    <div class="F_info">
        <a href="{$tsConfig.url}/files/{$filesUser.user_name}/{$folder.1}/{$folder.2}"><h2 id="Folder_name">{$folder.0}</h2></a>
        Hace unos segundos            
        Carpeta <span id="Folder_privado_{$folder.1}">Privada</span><br />
        <a href="#" onclick="borrar_folder({$folder.1}, false); return false;" class="">Borrar</a> |
        <a href="#" onclick="editar_folder({$folder.1}, '{$folder.0}', false); return false;" class="">Editar nombre</a> |
        <a href="#" class="qtip Folder_privado_{$folder.1}" style="display: none;" onclick="folder_private({$folder.1}, 1); return false;" title="Cambiar a privado">Privado</a>
        <a href="#" class="Qtip Folder_privado_{$folder.1}" onclick="folder_private({$folder.1}, 0); return false;" title="Cambiar a p&uacute;blico">P&uacute;blico</a>
    </div>
</div>