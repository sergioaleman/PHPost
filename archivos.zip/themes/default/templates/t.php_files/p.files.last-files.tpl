{foreach from=$tsLastFiles.data item=a}
<div class="list_file" id="File_{$a.file_id}" {if $a.f_estado == 0}style="opacity: 0.5;" title="Este archivo est&aacute; desabilitado"{/if}>
	<a href="{$tsConfig.url}/files/{$a.file_id}/{$a.f_nombre|seo}">
	<div class="File_format">
		<img src="{$tsConfig.images}/files/file.png" height="55"/>
		<span>{$a.f_ext}</span>
	</div>
	</a>
	<div class="F_info">
		<a href="{$tsConfig.url}/files/{$a.file_id}/{$a.f_nombre|seo}" class=""><h2 id="File_nombre">{$a.f_nombre|truncate:75}</h2></a>
		Subido {$a.f_fecha|fecha}
		Tama&ntilde;o: <strong>{$a.f_peso}</strong>
		Comentarios: <strong>{$a.f_comentarios}  </strong>              
		Archivo <span id="File_privado_{$a.file_id}">{if $a.f_privado == 1}Privado{else}P&uacute;blico{/if}</span><br />
		Subido por: <a href="{$tsConfig.url}/perfil/{$a.user_name}">{$a.user_name}</a>
	</div>
</div>
{/foreach}
{if $tsLastFiles.pages.pages > 0}
<div class="F_pag" style="overflow: hidden; padding: 5px;">
	{if $tsLastFiles.pages.prev > 0 && $tsLastFiles.pages.max == false}
	<a href="#" onclick="last_files('{$tsLastFiles.pages.prev}'); return false" class="floatL Abtn b_blue">Anterior</a>
	{/if}
	{if $tsLastFiles.pages.next <= $tsLastFiles.pages.pages}
	<a href="#" onclick="last_files('{$tsLastFiles.pages.next}'); return false" class="floatR Abtn b_blue">Siguiente</a>
	{/if}
</div>
{/if}