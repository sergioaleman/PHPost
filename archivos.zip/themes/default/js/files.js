// JavaScript files Kmario19 

/* Borrar Archivo */
function borrar_file(id, action){
	if (action == false) {
		mydialog.show();
		mydialog.title('Borrar archivo');
		mydialog.body('&iquest;Seguro que deseas borrar este archivo?');
		mydialog.buttons(true, true, 'S&iacute;', 'borrar_file('+id+', true)', true, false, true, 'No', 'close', true, true);
		mydialog.center();
		return;
	} else if (action == true)
	mydialog.procesando_inicio('Eliminando...', 'Borrar archivo');
    $('#loading').fadeIn(250);
	$.ajax({		
		type: 'POST',
		url: global_data.url + '/files-borrar.php',
		data: 'fileid='+id,
		success: function(h){
			switch(h.charAt(0)){
				case '0': //Error
					mydialog.procesando_fin();
					mydialog.alert('Error', h.substring(3));
					break;
				case '1':
					if($('#del_file').val() == 'true') {
						location.href = global_data.url + '/files/';
					} else {
						$('#File_'+id).fadeOut(500, function() {
							$(this).remove();
						});
						var count = parseInt($('#File_total').html())-1;
						$('#File_total').html(count);
						mydialog.close();
					}
					break;
				case '2':
					mydialog.procesando_fin();
					mydialog.alert('Exito', h.substring(3));
					$('#File_'+id).css({opacity: 0.5});
					var count = parseInt($('#Files_total').html())-1;
					$('#Files_total').html(count);
					break;
			}
            $('#loading').fadeOut(350);
		}
	});
}

/* Borrar Archivo Administrador */
function adminborrar_file(id, action){
	if (action == false) {
		mydialog.show();
		mydialog.title('Borrar archivo');
		mydialog.body('&iquest;Seguro que deseas borrar este archivo permanentemente?');
		mydialog.buttons(true, true, 'S&iacute;', 'adminborrar_file('+id+', true)', true, false, true, 'No', 'close', true, true);
		mydialog.center();
		return;
	} else if (action == true)
	mydialog.procesando_inicio('Eliminando...', 'Borrar archivo');
    $('#loading').fadeIn(250);
	$.ajax({		
		type: 'POST',
		url: global_data.url + '/files-borrar_admin.php',
		data: 'fileid='+id,
		success: function(h){
			switch(h.charAt(0)){
				case '0': //Error
					mydialog.procesando_fin();
					mydialog.alert('Error', h.substring(3));
					break;
				case '1':
					mydialog.procesando_fin();
					mydialog.alert('Exito', h.substring(3));
					document.location.href= global_data.url + '/files/';
					break;
			}
            $('#loading').fadeOut(350);
		}
	});
}

/* Reestablecer Archivo - Administrador */
function reactivar_file(id){
    $('#loading').fadeIn(250);
	$.ajax({		
		type: 'POST',
		url: global_data.url + '/files-reactivar.php',
		data: 'fileid='+id,
		success: function(h){
			switch(h.charAt(0)){
				case '0': //Error
					mydialog.procesando_fin();
					mydialog.alert('Error', h.substring(3));
					break;
				case '1':
					mydialog.alert('Exito', h.substring(3));
					$('#File_deleted').slideToggle();
					break;
			}
            $('#loading').fadeOut(350);
		}
	});
}


/* Editar nombre del archivo */
function editar_nombre(id, titulo, action){
	if (!action) {
		mydialog.show();
		mydialog.title('Editar nombre');
		mydialog.body('<input type="text" value="'+titulo+'" id="file_name" size="55">');
		mydialog.buttons(true, true, 'Cambiar', 'editar_nombre('+id+','+false+','+true+')', true, false, true, 'Cancelar', 'close', true, true);
		mydialog.center();
		return;
	} else {		
		var nombre = $('#file_name').val();		
		mydialog.procesando_inicio('Cambiando nombre...', 'Editar nombre');
		$('#loading').fadeIn(250);
		$.ajax({		
			type: 'POST',
			url: global_data.url + '/files-editar.php',
			data: 'fileid='+id+'&nombre='+nombre,
			success: function(h){
				switch(h.charAt(0)){
					case '0': //Error
						mydialog.procesando_fin();
						mydialog.alert('Error', h.substring(3));
						break;
					case '1':
						$('#File_' + id + ' .File_nombre').html(nombre);
						mydialog.close();
						break;
				}
				$('#loading').fadeOut(350);
			}
		});
	}
}


/* Cambiar privacidad del archivo */
function file_private(id, privado) {
    $('#loading').fadeIn(250);
	$.ajax({		
		type: 'POST',
		url: global_data.url + '/files-privado.php',
		data: 'fileid='+id+'&privado='+privado,
		success: function(h){
			switch(h.charAt(0)){
				case '0': //Error
					mydialog.alert('Error', h.substring(3));
					break;
				case '1':
					if (privado == 1) {
						$('#File_privado_'+id).html('Privado');						
					} else {
						$('#File_privado_'+id).html('P&uacute;blico');
					}
					$('.File_privado_b'+id).toggle();
					break;
			}
            $('#loading').fadeOut(350);
		}
	});
}

/* Descargar archivo y sumar estadisticas */
function download_file(id) {
    $('#loading').fadeIn(250);
	$('#btn_downloadfile').attr({'onclick':'', 'disabled':'disabled'});
	$.ajax({		
		type: 'POST',
		url: global_data.url + '/files-descargar.php',
		data: 'fileid='+id,
		success: function(h){
			switch(h.charAt(0)){
				case '0': //Error
					mydialog.alert('Error', h.substring(3));
					break;
				case '1':
					document.location.href = global_data.url + '/files/bajar/?fileid=' + id;
					break;
			}
            $('#loading').fadeOut(350);
		}
	});
}

/* Agregar archivo a favoritos */
function favorit_file(id) {
    $('#loading').fadeIn(250);
	$('#btn_favoritfile').attr({'onclick':'', 'disabled':'disabled'});
	$.ajax({		
		type: 'POST',
		url: global_data.url + '/files-favorito.php',
		data: 'fileid='+id,
		success: function(h){
			switch(h.charAt(0)){
				case '0': //Error
					mydialog.alert('Error', h.substring(3));
					break;
				case '1':
					$('#File_Fav').show();
					$('.btn_favoritfile').toggle();
					break;
			}
            $('#loading').fadeOut(350);
		}
	});
}

/* Borrar favorito */
function borrar_fav(id, action){
	if (action == false) {
		mydialog.show();
		mydialog.title('Eliminar favorito');
		mydialog.body('&iquest;Seguro que borrar este favorito?');
		mydialog.buttons(true, true, 'S&iacute;', 'borrar_fav('+id+', true)', true, false, true, 'No', 'close', true, true);
		mydialog.center();
		return;
	} else if (action == true)
	mydialog.procesando_inicio('Eliminando...', 'Eliminar favorito');
    $('#loading').fadeIn(250);
	$.ajax({		
		type: 'POST',
		url: global_data.url + '/files-delfav.php',
		data: 'favid='+id,
		success: function(h){
			switch(h.charAt(0)){
				case '0': //Error
					mydialog.procesando_fin();
					mydialog.alert('Error', h.substring(3));
					break;
				case '1':
					mydialog.close();
					$('#Favid_'+id).remove();
					$('#File_Fav').hide();
					$('.btn_favoritfile').toggle();
					var count = parseInt($('#Favs_total').html())-1;
					$('#Favs_total').html(count);
					break;
			}
            $('#loading').fadeOut(350);
		}
	});
}

/* Agregar nuevo comentario */
function file_newcom(id) {
	// EVITAR FLOOD
	$('#btn_newcom').attr({'disabled':'disabled'});
	var text = $('#file_newcom').val();
	// ESTA VACIO?
	if(text == ''){
		textarea.focus();
		$('#btn_newcom').attr({'disabled':''});
		return;
	}else if(text.length > 1500){
		mydialog.alert("Tu comentario no puede ser mayor a 1500 caracteres.");
		textarea.focus();
		$('#btn_newcom').attr({'disabled':''});
		return;
	}
	// CARGANDO...
	$('#newcom_loader').fadeIn();
	$('#loading').fadeIn(250);                                 
	$.ajax({
		type: 'POST',
		url: global_data.url + '/files-newcom.php',
		data: 'body=' + encodeURIComponent(text) + '&fileid=' + id,
		success: function(h){
			if(h.charAt(0) == '0'){
				$('#alertcom_file').html('<div class="mensajes error">'+h.substring(3)+'</div>').show('slow');
				$('#btn_newcom').attr({'disabled':''});
			} else {
				$("#add_new_com").slideUp();
				$('#add_new_com').html(h).slideDown('slow', function () {
					$('#sincom_file').hide('slow');
					$('#alertcom_file').html('<div class="emptyData">Tu comentario fue agregado correctamente.</div>');
				});
				// SUMAMOS
				var com_total = parseInt($('#com_total').text());
				$('#com_total').text(com_total + 1);
				$('#add_newcom').hide('slow');
			}
			$('#loading').fadeOut(350);                                 
			//
			$('#newcom_loader').fadeOut();
			mydialog.close();
		}
	 });
}

/* Borrar comentario */
function borrar_comfile(id, fileid, action){
	if (action == false) {
		mydialog.show();
		mydialog.title('Eliminar comentario');
		mydialog.body('&iquest;Seguro que borrar este comentario?');
		mydialog.buttons(true, true, 'S&iacute;', 'borrar_comfile('+id+', '+fileid+', true)', true, false, true, 'No', 'close', true, true);
		mydialog.center();
		return;
	} else if (action == true)
	mydialog.procesando_inicio('Eliminando...', 'Eliminar comentario');
    $('#loading').fadeIn(250);
	$.ajax({		
		type: 'POST',
		url: global_data.url + '/files-delcom.php',
		data: 'comid='+id+'&fileid='+fileid,
		success: function(h){
			switch(h.charAt(0)){
				case '0': //Error
					mydialog.procesando_fin();
					mydialog.alert('Error', h.substring(3));
					break;
				case '1':
					mydialog.close();
					var count = parseInt($('#com_total').html())-1;
					$('#com_total').html(count);
					if(count == 0) {
						$('#sincom_file').show('slow');	
					}
					$('#comfile_'+id).fadeOut(500, function() {
						$(this).remove();
					});					
					break;
			}
            $('#loading').fadeOut(350);
		}
	});
}

/* Citar comentario */
function citar_com(id, nick){
	var textarea = $('#file_newcom');
	textarea.focus();
	textarea.val(((textarea.val()!='') ? textarea.val() + '\n' : '') + '[quote=' + nick + ']' + htmlspecialchars_decode($('#c_source_'+id).html(), 'ENT_NOQUOTES') + '[/quote]\n');
}

/* Botones para comentar */
mySettings_file = {
	nameSpace: 'markitfile',
	resizeHandle: true,
	markupSet: [
		{name:lang['Negrita'], key:'B', openWith:'[b]', closeWith:'[/b]'},
		{name:lang['Cursiva'], key:'I', openWith:'[i]', closeWith:'[/i]'},
		{name:lang['Subrayado'], key:'U', openWith:'[u]', closeWith:'[/u]'},
		{separator:'-' },
		{name:lang['Alinear a la izquierda'], key:'', openWith:'[align=left]', closeWith:'[/align]'},
		{name:lang['Centrar'], key:'', openWith:'[align=center]', closeWith:'[/align]'},
		{name:lang['Alinear a la derecha'], key:'', openWith:'[align=right]', closeWith:'[/align]'},
		{separator:'-' },
		{name:lang['Color'], dropMenu: [
			{name:lang['Rojo'], openWith:'[color=red]', closeWith:'[/color]' },
			{name:lang['Naranja'], openWith:'[color=orange]', closeWith:'[/color]' },
			{name:lang['Verde'], openWith:'[color=green]', closeWith:'[/color]' },
			{name:lang['Azul'], openWith:'[color=blue]', closeWith:'[/color]' }
		]},
		{name:lang['Tamano'], dropMenu :[
			{name:lang['Pequena'], openWith:'[size=9]', closeWith:'[/size]' },
			{name:lang['Normal'], openWith:'[size=12]', closeWith:'[/size]' },
			{name:lang['Grande'], openWith:'[size=18]', closeWith:'[/size]' }
		]}
	]
};

/* Crear nueva carpeta */
function new_folder(action) {
	if (empty(action)) {
		mydialog.show();
		mydialog.title('Nueva Carpeta');
		mydialog.body('<input type="text" placeholder="Nombre de la carpeta..." id="folder_name" size="55">');
		mydialog.buttons(true, true, 'Crear', 'new_folder(true)', true, false, true, 'Cancelar', 'close', true, true);
		mydialog.center();
		$('#folder_name').focus();
		return;
	} else if (action == true) {
		var nombre = $('#folder_name').val();
		if (empty(nombre)) $('#folder_name').focus();
		else {
			mydialog.procesando_inicio();
			$('#loading').fadeIn(250);                                 
			$.ajax({
				type: 'POST',
				url: global_data.url + '/files-newfolder.php',
				data: 'nombre=' + nombre,
				success: function(h){
					switch(h.charAt(0)){
						case '0': //Error
							mydialog.procesando_fin();
							mydialog.alert('Error', h.substring(3));
							break;
						case '1': //OK
								$('#F_newfolder').html(h.substring(3)).slideDown('slow');
								mydialog.procesando_fin();
								$('#loading').fadeOut(350);
								mydialog.close();
							break;
					}
				}
			 });
		}
	}
}

/* Cambiar privacidad de la carpeta */
function folder_private(id, privado) {
    $('#loading').fadeIn(250);
	$.ajax({		
		type: 'POST',
		url: global_data.url + '/files-privfolder.php',
		data: 'folderid='+id+'&privado='+privado,
		success: function(h){
			switch(h.charAt(0)){
				case '0': //Error
					mydialog.alert('Error', h.substring(3));
					break;
				case '1':
					if (privado == 1) {
						$('#Folder_privado_'+id).html('Privado');						
					} else {
						$('#Folder_privado_'+id).html('P&uacute;blico');
					}
					$('.Folder_privado_'+id).toggle();
					break;
			}
            $('#loading').fadeOut(350);
		}
	});
}

/* Borrar Carpeta */
function borrar_folder(id, action){
	if (empty(action)) {
		mydialog.show();
		mydialog.title('Borrar carpeta');
		mydialog.body('&iquest;Seguro que deseas borrar esta carpeta?<br /><br />Si tiene archivos, volveran a la carpeta raiz.');
		mydialog.buttons(true, true, 'S&iacute;', 'borrar_folder('+id+', 1)', true, false, true, 'No', 'close', true, true);
		mydialog.center();
		return;
	} else {
		mydialog.procesando_inicio();
		$('#loading').fadeIn(250);
		$.ajax({		
			type: 'POST',
			url: global_data.url + '/files-delfolder.php',
			data: 'folderid='+id,
			success: function(h){
				switch(h.charAt(0)){
					case '0': //Error
						mydialog.alert('Error', h.substring(3));
						break;
					case '1':
						$('#folderid_'+id).fadeOut(500, function() {
							$(this).remove();
						});
						mydialog.close();
						break;
				}
				$('#loading').fadeOut(350);
			}
		});
	}
}

/* Cambiar nombre de carpeta */
function editar_folder(id, titulo, action) {
	if (empty(action)) {
		mydialog.show();
		mydialog.title('Nueva Carpeta');
		mydialog.body('<input type="text" value="'+titulo+'" id="folder_name" size="55">');
		mydialog.buttons(true, true, 'Aceptar', 'editar_folder('+id+', 0, 1)', true, false, true, 'Cancelar', 'close', true, true);
		mydialog.center();
		$('#folder_name').focus();
		return;
	} else {
		var nombre = $('#folder_name').val();
		if (empty(nombre)) $('#folder_name').focus();
		else {
			mydialog.procesando_inicio();
			$('#loading').fadeIn(250);                                 
			$.ajax({
				type: 'POST',
				url: global_data.url + '/files-editfolder.php',
				data: 'nombre=' + nombre + '&folderid=' + id,
				success: function(h){
					switch(h.charAt(0)){
						case '0': //Error							
							mydialog.procesando_fin();
							mydialog.alert('Error', h.substring(3));
							break;
						case '1': //OK
							$('#folderid_'+id+' > .F_info > a > h2').text(nombre);
							mydialog.close();
							break;
					};
				}
			 });
			$('#loading').fadeOut(350);
		}
	}
}

/* Mover archivos a carpetas */
var folder = {
	cargar: function(id){
		$('#loading').fadeIn(250);
		mydialog.show(true);
		mydialog.title('Mover este archivo');
		mydialog.procesando_inicio();
		mydialog.center();
		$.ajax({
			type: 'POST',
			url: global_data.url +'/files-verfolders.php',
			dataType: 'json',
			success: function(h){
				switch(h.folders){
					case 0: //Error
						mydialog.procesando_fin();
						mydialog.alert('Error', h['data']);
					break;
					case 1: //OK
						mydialog.procesando_fin();
						var html = '<div>Seleccionar carpeta a mover archivo</div><br />';
						html += '<select id="Folder_id" title="Seleccionar carpeta a mover">';
						html += '<option selected="selected">Seleccionar carpeta...</option>';
						html += '<option value="0">Carpeta raiz</option>';
						for(var i = 0; i < h.data.length; i++){
							html += '<option value="' + h.data[i].folder_id + '">' + h.data[i].folder_name + '</option>';
						}
						html += '</select>';				
						mydialog.body(html);
						mydialog.buttons(true, true, 'Mover', 'folder.mover('+id+')', true, false, true, 'Cancelar', 'close', true, true);
						mydialog.center();
					break;
				}            
				$('#loading').fadeOut(350);
			}
		});
	},
	mover: function(fileid) {
		var folderid = $('#Folder_id').val();
		mydialog.procesando_inicio();
		$.ajax({		
			type: 'POST',
			url: global_data.url + '/files-moverfile.php',
			data: 'folderid='+folderid+'&fileid='+fileid,
			success: function(h){
				switch(h.charAt(0)){
					case '0': //Error
						mydialog.procesando_fin();
						mydialog.alert('Error', h.substring(3));
						break;
					case '1':
						$('#File_'+fileid).fadeOut(500, function() {
							$(this).remove();
						});
						mydialog.close();
						break;
				}
				$('#loading').fadeOut(350);
			}
		});
	}
}

/* Buscar archivos */
function file_search(userid, folderid) {
	var text =  $('#F_search').val();
	if(text != '' && text.length >= 3) {
		$('#loading').fadeIn(350);
		$.ajax({
			type: 'POST',
			url: global_data.url + '/files-search.php',
			data: 'userid=' + userid + '&folderid=' + folderid + '&text=' + text,
			success: function(h){
				$('#SearchResult').slideDown(500, function() {
					$('#SearchResult').html(h);
				});
			}
		});
		$('#loading').fadeOut(350);
	}
}

/* De los seleccionados... EN DESSARROLLO */
var check = {
	marcar: function() {
		$('#FA_seleccionados').slideDown();
	},	
	todos: function(){
		var input = $('input[type="checkbox"]');
		if(input.attr('checked') == 'checked') {
			input.removeAttr('checked');
		} else {
			input.attr({'checked' : 'checked'});
		}
	},	
	recor: function() {
		var c_vals = new Array();
		$('input[type="checkbox"]').each(function () {
			if(this.checked) {
				c_vals.push($(this).val());
			}
		});
		return c_vals;
	},
	borrar: function(action) {
		var elmts = check.recor();
		if(elmts.length==0) return mydialog.alert('Error', 'Selecciona un archivo primero.');
		if (!action) {
			mydialog.show();
			mydialog.title('Borrar archivos seleccionados');
			mydialog.body('&iquest;Seguro que deseas borrar estos <b>'+elmts.length+'</b> archivos?');
			mydialog.buttons(true, true, 'S&iacute;', 'check.borrar(true)', true, false, true, 'No', 'close', true, true);
			mydialog.center();
			return;
		} else if (action == true)
		mydialog.procesando_inicio('Eliminando...', 'Borrar archivo');
		$('#loading').fadeIn(250);
		$.ajax({		
			type: 'POST',
			url: global_data.url + '/files-borrar_select.php',
			data: 'files='+elmts,
			success: function(h){
				mydialog.procesando_fin();
				$('#loading').fadeOut(350);
				switch(h.charAt(0)){
					case '0': //Error
						mydialog.alert('Error', h.substring(3));
						break;
					case '1':
						mydialog.alert('Exito', h.substring(3));
						location.reload();
						break;
				}
			}
		});
	},
	cargar: function() {
		if(check.recor().length==0) return mydialog.alert('Error', 'Selecciona un archivo primero.');
		$('#loading').fadeIn(250);
		mydialog.show(true);
		mydialog.title('Mover archivos seleccionados');
		mydialog.procesando_inicio();
		mydialog.center();
		$.ajax({
			type: 'POST',
			url: global_data.url +'/files-verfolders.php',
			dataType: 'json',
			success: function(h){
				switch(h.folders){
					case 0: //Error
						mydialog.procesando_fin();
						mydialog.alert('Error', h['data']);
					break;
					case 1: //OK
						mydialog.procesando_fin();
						var html = '<div>Seleccionar carpeta a mover archivo</div><br />';
						html += '<select id="Folder_id" title="Seleccionar carpeta a mover">';
						html += '<option selected="selected">Seleccionar carpeta...</option>';
						html += '<option value="0">Carpeta raiz</option>';
						for(var i = 0; i < h.data.length; i++){
							html += '<option value="' + h.data[i].folder_id + '">' + h.data[i].folder_name + '</option>';
						}
						html += '</select>';				
						mydialog.body(html);
						mydialog.buttons(true, true, 'Mover', 'check.mover()', true, false, true, 'Cancelar', 'close', true, true);
						mydialog.center();
					break;
				}            
				$('#loading').fadeOut(350);
			}
		});
	},
	mover: function() {		
		var elmts = check.recor();
		if(elmts.length==0) return mydialog.alert('Error', 'Selecciona un archivo primero.');
		var folderid = $('#Folder_id').val();
		mydialog.procesando_inicio('Mover archivos seleccionados', 'Moviendo archivos, espere...');
		$('#loading').fadeIn(250);
		$.ajax({		
			type: 'POST',
			url: global_data.url + '/files-mover_select.php',
			data: 'files='+elmts+'&folderid='+folderid,
			success: function(h){
				mydialog.procesando_fin();
				$('#loading').fadeOut(350);
				switch(h.charAt(0)){
					case '0': //Error
						mydialog.alert('Error', h.substring(3));
						break;
					case '1':
						mydialog.alert('Exito', h.substring(3));
						location.reload();
						break;
				}
			}
		});
	}
}

/* Mostrar herramientas de archivo */
function FB_herramientas() {
	$('#FB_herramientas').slideToggle();
	if($('#FB_cross').html() == '+') {
		$('#FB_cross').html('-');
	} else {
		$('#FB_cross').html('+');
	}
}

/* Paginador ultimos archivos publicos */
function last_files(page){
    $('#loading').fadeIn(250);
    $('#more_last_files').css('opacity', '0.5');
    $.get(global_data.url + '/files-last-files.php', 'page=' + page, function(h){
	   success: { $('#more_last_files').html(h).css('opacity', '1'); $('#loading').fadeOut(350); }
	});
    return false;
}

/* Porcentaje de carga [NUEVO] */
$(document).ready(function(){
	if($('#file_newcom') && !$('#markItUpbody_comm').length){
		$('#file_newcom').markItUp(mySettings_file);
	}
	var msj = $("#message");
	var percent = $('#percent')
	var bar = $("#bar");
	document.getElementById('New_upload').onsubmit = function() {
		$('#start_upload').hide().attr('disabled','disabled');
		bar.width('0%');
		msj.html("").hide();
		percent.html("0%");
		$("#progress").fadeIn(250);
		var xhr = new XMLHttpRequest();	
		xhr.upload.addEventListener('progress', function(e) {
			if (e.lengthComputable) {
				var percentage = Math.round((e.loaded * 100) / e.total);
				percent.html(percentage + '%');
				bar.width(percentage+'%');
			}
		}, false);
		xhr.open('post', global_data.url+'/files-subir.php', true);
		xhr.onreadystatechange = function() {
			if (xhr.readyState == 4 && xhr.status == 200) {
				var result = xhr.responseText;
				if(result.charAt(0) == 1) {
					msj.removeClass('upload_error').addClass('upload_ok');
					$('#start_upload').slideUp(100);
					msj.html(result.substring(3));				
				} else {
					msj.removeClass('upload_ok').addClass('upload_error');
					msj.html(result);
				}
				msj.show();
				$('#start_upload').removeAttr('disabled');
			}
		}
		xhr.send(new FormData(this));
	};
	$('#New_file').bind('change', function() {
		if($('#New_file').val() == '') {
			$('.result_text').hide().html('');
			$('#start_upload').hide();
		} else {
			$('.result_text').html($('#New_file').val().substring(12)).fadeIn(100);
			$('#start_upload').fadeIn(100);
		}
		$("#progress").hide();
		bar.width('0%');
		msj.html("").hide();
		percent.html("0%");
	});
    $("#New_upload").ajaxForm();
})