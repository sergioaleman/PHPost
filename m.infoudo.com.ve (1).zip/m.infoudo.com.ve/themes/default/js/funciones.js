function menu_toggle(type) {
	var c = $("#brandday");
	if(type == 1) {
		if(c.hasClass("sidebar-visible")){
			c.css({height:"auto",overflow:""});
		}else{
			c.css({height:c.find(".menu")[0].offsetHeight+"px",overflow:"hidden"});		
		}
		c.toggleClass("sidebar-visible");
	} else if(type == 2) {
		if(c.hasClass("sidebar-visible")){
			c.css({height:"auto",overflow:""});
		}
	}
}
// NEWS
var news = {
    total: 0,
    count: 1,
    slider: function(){
        if(news.total > 1){
            if(news.count < news.total) news.count++;
            else news.count = 1;
            //
            $('#top_news > li').hide();
            $('#new_' + news.count).fadeIn();
            // INFINITO :D
            setTimeout("news.slider()",7000);
        }
    }       
}

// READY
$(document).ready(function(){
    /* NOTICIAS */
    news.total = $('#top_news > li').size();
    news.slider();
});