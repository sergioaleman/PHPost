var muro = {
    stream: {
        total: 0, // TOTAL DE PUBLICACIONES CARGADAS
        show: 10, // CUANTOS SE MUESTRAN POR CADA CARGA
        // COMPARTIR
        compartir: function(){
			$('#add_comment').attr({'disabled':'disabled'});       
			if($('.box_comentario textarea').val() != '' || $('.box_comentario textarea').val().length > 0) {            
				muro.stream.loader(true);
				var data = $('.box_comentario textarea').val();
				$.ajax({
					type: 'POST',
					url: global_data.url + '/muro-stream.php?do=post',
					data: 'data=' + encodeURIComponent(data) + '&pid=' + $('#info').val(),
					success: function(h){
						switch(h.charAt(0)){
							case '0': //Error
								$('.box_comentario #error').html(h.substring(3)).show();
								break;
							case '1': //OK
								// ESCONDEMOS SI ES EL PRIMER COMENTARIO
								if($('#perfil_wall .emptyData')) $('#perfil_wall .emptyData').hide();
								$('.box_comentario #error').hide();
								$('.shouts').prepend($(h.substring(3)).show());
								$('.box_comentario textarea').val('');
								break;
						}
					},
					complete: function (){
						// LOADER/ STATUS
						muro.stream.loader(false);
						$('#add_comment').removeAttr('disabled');
					}
				});
			} else {
				$('.box_comentario textarea').focus();
				$('#add_comment').removeAttr('disabled');
			}
		
        },
        loadMore: function(type){
            // SI ESTA OCUPADO NO HACEMOS NADA
            if(scrollContinue == false) return false;
			else scrollContinue = false;
			$('.load-more').attr({'disabled':'disabled'});  
            // LOADER
            $.ajax({
            	type: 'POST',
            	url: global_data.url + '/muro-stream.php?do=more&act=' + type,
            	data: 'pid=' + $('#info').val() + '&start=' + muro.stream.total,
            	success: function(h){
					// CARGAMOS AL DOM
					$('.shouts').append(h.substring(3));
					// VALIDAMOS
					var total_pubs = $('#total_pubs').attr('val');
					total_pubs = parseInt(total_pubs);
					// 
					var msg = 'No hay m&aacute;s mensajes para mostrar.'; 
					if(total_pubs == 0 || total_pubs < muro.stream.show) $('.load-more').html(msg).attr('onClick', 'return false');
					else muro.stream.total = muro.stream.total + parseInt(total_pubs);
					// REMOVER
					$('#total_pubs').remove();
            	},
                complete: function (){
                    scrollContinue = true;
					$('.load-more').removeAttr('disabled');
                }
            });
        },
        // LOADER
        loader: function(active){
            if(active == true) $('#comment_loading').show();
            else if(active == false) $('#comment_loading').hide();
        }
    },
    // LIKE
    like_this: function(id){
		if(muro.stream.status == 1) return false;
        else muro.stream.status = 1;
		$('#pub_' + id + ' .shbtn.shlike').toggleClass('ok');
		if($('#pub_' + id + ' .shbtn.shlike').hasClass('ok')) {
			var suma = parseInt($('#tlikes_' + id).html())+1;
			var resta = suma-1;
		} else {
			var suma = parseInt($('#tlikes_' + id).html())-1;
			var resta = suma+1;
		}
		$('#tlikes_' + id).html(parseInt(suma));
        // MANDAMOS
        $.ajax({
        	type: 'POST',
        	url: global_data.url + '/muro-likes.php',
            dataType: 'json',
        	data: 'id=' + id,
        	success: function(h){
        	   if(h['status'] == 'ok'){
				   	$('#pub_' + id + ' #error').hide();
        	   } else {
        	       $('#pub_' + id + ' #error').html(h['text'].substring(3)).show();
				   $('#tlikes_' + id).html(parseInt(resta));
				   $('#pub_' + id + ' .shbtn.shlike').toggleClass('ok');
        	   }
               $('#loading').slideUp(350); 
        	},
            complete: function (){
                // STATUS
                muro.stream.status = 0;
            }
        });
    },
    comentar: function(id){
		$('#add_comment').attr({'disabled':'disabled'});       
		if($('.box_comentario textarea').val() != '' || $('.box_comentario textarea').val().length > 0) {            
			muro.stream.loader(true);
			var data = $('.box_comentario textarea').val();
			$.ajax({
				type: 'POST',
				url: global_data.url + '/muro-stream.php?do=repost',
				data: 'data=' + encodeURIComponent(data) + '&pid=' + id,
				success: function(h){
					switch(h.charAt(0)){
						case '0': //Error
							$('.box_comentario #error').html(h.substring(3)).show();
							break;
						case '1': //OK
							$('#no-comments').remove();
							$('.box_comentario #error').hide();
							$('#nuevos').prepend(h.substring(3)).show();
							$('.box_comentario textarea').val('');
							$('#add_comment'). removeAttr('disabled');
							break;
					}
				},
				complete: function (){
					muro.stream.loader(false);
					$('#add_comment').removeAttr('disabled');
				}
			});
		} else {
			$('.box_comentario textarea').focus();
			$('#add_comment').removeAttr('disabled');
		}
    },
    // MOSTRAR VIDEO DEL MURO
    load_atta: function(type, ID, obj){
        switch(type){
            case 'foto':
                var content = '<center><img src="' + ID + '" style="max-width:' + this.maxWidth + 'px; max-height: 380px" /><center>'; //bzox
            break;
            case 'video':
				var content = '<div style="position: relative;width: 100%;padding-top: 56.25%"><iframe width="100%" height="100%" src="//www.youtube.com/embed/' + ID +'" frameborder="0" allowFullScreen style="position: absolute;left: 0;top: 0;"></iframe></div>';
            break;
        }
        // CARGAMOS
        $(obj).parent().html(content);
    }
}