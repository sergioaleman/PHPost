<?php /* Smarty version 2.6.26, created on 2024-08-10 09:11:38
         compiled from t.php_files/p.posts.load_more.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'modules/m.home_last_posts.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<input type="hidden" id="total_posts" value="<?php echo $this->_tpl_vars['tsPosts']['total']; ?>
" />