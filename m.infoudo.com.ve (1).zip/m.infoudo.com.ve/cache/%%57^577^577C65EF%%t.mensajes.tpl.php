<?php /* Smarty version 2.6.26, created on 2024-08-10 09:17:46
         compiled from t.mensajes.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'fecha', 't.mensajes.tpl', 15, false),array('modifier', 'nl2br', 't.mensajes.tpl', 52, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php if ($this->_tpl_vars['tsAction'] == '' || $this->_tpl_vars['tsAction'] == 'enviados' || $this->_tpl_vars['tsAction'] == 'respondidos' || $this->_tpl_vars['tsAction'] == 'search'): ?>
<div class="blanco">
    <h1 class="Titulo">Mensajes<a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/mensajes/nuevo/" class="floatR">Nuevo mensaje</a></h1>
    <?php if ($this->_tpl_vars['tsMensajes']['data']): ?>
    <ul class="monitor">
        <?php $_from = $this->_tpl_vars['tsMensajes']['data']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['mp']):
?>
        <li <?php if ($this->_tpl_vars['mp']['mp_read_to'] == 0): ?>class="unread"<?php endif; ?>>
            <a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/perfil/<?php echo $this->_tpl_vars['noti']['user']; ?>
" class="avatar">
                <img height="32" width="32" src="<?php echo $this->_tpl_vars['tsConfig']['web']; ?>
/files/avatar/<?php echo $this->_tpl_vars['mp']['mp_from']; ?>
_50.jpg"/>
            </a>
            <div class="m_info">
                <div class="m_autor">
                    <a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/perfil/<?php echo $this->_tpl_vars['mp']['user_name']; ?>
"><?php echo $this->_tpl_vars['mp']['user_name']; ?>
</a> 
                    <span class="time"><?php echo ((is_array($_tmp=$this->_tpl_vars['mp']['mp_date'])) ? $this->_run_mod_handler('fecha', true, $_tmp, 'd_Ms_a') : smarty_modifier_fecha($_tmp, 'd_Ms_a')); ?>
</span>
                </div>
                <div class="m_body">
                    <a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/mensajes/leer/<?php echo $this->_tpl_vars['mp']['mp_id']; ?>
" class="body_link"><strong><?php echo $this->_tpl_vars['mp']['mp_subject']; ?>
</strong><br /><?php echo $this->_tpl_vars['mp']['mp_preview']; ?>
</a>
                </div>
            </div>
        </li>
        <?php endforeach; endif; unset($_from); ?>
    </ul>
    <?php else: ?>
    <div class="emptyData">No hay mensajes</div>
    <?php endif; ?>
    <?php if ($this->_tpl_vars['tsMensajes']['pages']['prev'] != 0 || $this->_tpl_vars['tsMensajes']['pages']['next'] != 0): ?>
    <div class="mpFooter">	   
        <?php if ($this->_tpl_vars['tsMensajes']['pages']['prev'] != 0): ?>
        <a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/mensajes/<?php if ($this->_tpl_vars['tsAction']): ?><?php echo $this->_tpl_vars['tsAction']; ?>
/<?php endif; ?>?page=<?php echo $this->_tpl_vars['tsMensajes']['pages']['prev']; ?>
<?php if ($this->_tpl_vars['tsQT'] != ''): ?>&qt=unread<?php endif; ?>" class="floatL btn_blue">Anterior</a>
        <?php endif; ?>
        <?php if ($this->_tpl_vars['tsMensajes']['pages']['next'] != 0): ?>
        <a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/mensajes/<?php if ($this->_tpl_vars['tsAction']): ?><?php echo $this->_tpl_vars['tsAction']; ?>
/<?php endif; ?>?page=<?php echo $this->_tpl_vars['tsMensajes']['pages']['next']; ?>
<?php if ($this->_tpl_vars['tsQT'] != ''): ?>&qt=unread<?php endif; ?>" class="floatR btn_blue">Siguiente</a><?php endif; ?>
    </div>
    <?php endif; ?>
</div>
<?php elseif ($this->_tpl_vars['tsAction'] == 'leer'): ?>
<div class="blanco">
    <h1 class="Titulo"><?php echo $this->_tpl_vars['tsMensajes']['msg']['mp_subject']; ?>
<span class="info">Entre <a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/perfil/<?php echo $this->_tpl_vars['tsUser']->nick; ?>
">T&uacute;</a> y <a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/perfil/<?php echo $this->_tpl_vars['tsMensajes']['ext']['user']; ?>
"><?php echo $this->_tpl_vars['tsMensajes']['ext']['user']; ?>
</a></span></h1>
    <ul class="monitor" id="misMps">
        <?php if ($this->_tpl_vars['tsMensajes']['res']): ?><?php $_from = $this->_tpl_vars['tsMensajes']['res']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['mp']):
?>
        <li>
            <a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/perfil/<?php echo $this->_tpl_vars['mp']['user_name']; ?>
" class="avatar">
                <img height="32" width="32" src="<?php echo $this->_tpl_vars['tsConfig']['web']; ?>
/files/avatar/<?php echo $this->_tpl_vars['mp']['mr_from']; ?>
_50.jpg"/>
            </a>
            <div class="m_info">
                <div class="m_autor">
                    <a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/perfil/<?php echo $this->_tpl_vars['mp']['user_name']; ?>
"><?php echo $this->_tpl_vars['mp']['user_name']; ?>
</a> 
                    <span class="time"><?php echo ((is_array($_tmp=$this->_tpl_vars['mp']['mr_date'])) ? $this->_run_mod_handler('fecha', true, $_tmp) : smarty_modifier_fecha($_tmp)); ?>
</span>
                </div>
                <div class="m_body">
                    <?php echo ((is_array($_tmp=$this->_tpl_vars['mp']['mr_body'])) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); ?>

                </div>
            </div>
        </li>
        <?php endforeach; endif; unset($_from); ?>
        <?php else: ?>
        <li class="emptyData">No se pudieron cargar los mensajes.</li>
        <?php endif; ?>
    </ul>
    <?php if ($this->_tpl_vars['tsUser']->is_admod || ( $this->_tpl_vars['tsMensajes']['msg']['mp_del_to'] == 0 && $this->_tpl_vars['tsMensajes']['msg']['mp_del_from'] == 0 && $this->_tpl_vars['tsMensajes']['ext']['can_read'] == 1 )): ?>
    <div class="box_comentario">
        <div class="caja_text">
            <img class="avatar" src="<?php echo $this->_tpl_vars['tsConfig']['web']; ?>
/files/avatar/<?php echo $this->_tpl_vars['tsUser']->uid; ?>
_50.jpg" width="40" />
            <textarea placeholder="Escribe un mensaje" id="body_comment"></textarea>
        </div>
        <div class="caja_boton">
            <img id="comment_loading" src="<?php echo $this->_tpl_vars['tsConfig']['images']; ?>
/loading.gif">
            <a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/mensajes/" class="btn_blue" style="float: left;">Volver</a>
            <input type="button" id="add_comment" value="Comentar" class="btn_blue" onclick="responder_mensaje(<?php echo $this->_tpl_vars['tsMensajes']['msg']['mp_id']; ?>
)" />
        </div>
        <div id="error"></div>
    </div>
    <?php else: ?>
    <li class="emptyData">Un participante abandon&oacute; la conversaci&oacute;n o no tienes permiso para responder</li>
    <?php endif; ?>
</div> 
<?php elseif ($this->_tpl_vars['tsAction'] == 'nuevo'): ?>
<form class="mp_nuevo box" action="javascript:mps.verify()">
    <div id="error"></div>
    <label for="para">Para</label>
    <input type="text" id="para" name="para" placeholder="Nick del usuario" class="input-text" />
    <label for="asunto">Asunto</label>
    <input type="text" id="asunto" name="asunto" placeholder="Asunto del mensaje" class="input-text" />
    <label for="asunto">Mensaje</label>
    <textarea id="mensaje" name="mensaje" placeholder="Asunto del mensaje" class="input-text" rows="6"></textarea>
    <div class="controls">
        <input type="submit" value="Enviar mensaje">
    </div>
</form>
<?php endif; ?>         
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>