<?php /* Smarty version 2.6.26, created on 2024-08-15 00:06:16
         compiled from sections/main_footer.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'sections/main_footer.tpl', 10, false),)), $this); ?>
</div>
        <!--end-cuerpo-->
        </div>
        <!--END CONTAINER-->
    <div id="footer">
        <footer>
            <a href="<?php echo $this->_tpl_vars['tsConfig']['web']; ?>
?mobile=desktop">Versi&oacute;n de escritorio</a>
        </footer>
        <div id="pp_copyright" style="text-align: center;">
            <a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
"><strong><?php echo $this->_tpl_vars['tsConfig']['titulo']; ?>
</strong></a> &copy; <?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, "%Y") : smarty_modifier_date_format($_tmp, "%Y")); ?>
 - Powered by <a href="http://www.alemansistem.es.tl/" target="_blank"><strong>Alemansistem</strong></a>
        </div>
    </div>
</div>
<div style="position:fixed; bottom:0; right:0; float:none;"><iframe src="https://www.facebook.com/plugins/like.php?href=http://www.facebook.com/InfoUDOmonagas1/&amp;layout=box_count&amp;show_faces=false&amp;width=450&amp;action=like&amp;colorscheme=light&amp;height=65" scrolling="no" frameborder="0" style="border:none; overflow:hidden;  min-width:51px;  max-width:79px; height:65px;" allowTransparency="true"></iframe></div>





</body>
</html>