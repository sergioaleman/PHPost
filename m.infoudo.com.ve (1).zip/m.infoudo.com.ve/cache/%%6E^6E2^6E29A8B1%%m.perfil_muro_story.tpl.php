<?php /* Smarty version 2.6.26, created on 2024-08-10 09:12:42
         compiled from modules/m.perfil_muro_story.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'fecha', 'modules/m.perfil_muro_story.tpl', 6, false),array('modifier', 'quot', 'modules/m.perfil_muro_story.tpl', 8, false),)), $this); ?>
<?php $_from = $this->_tpl_vars['tsMuro']['data']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['p']):
?>
<li class="shout" id="pub_<?php echo $this->_tpl_vars['p']['pub_id']; ?>
">
    <a class="userinfo" href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/perfil/<?php echo $this->_tpl_vars['p']['user_name']; ?>
">
        <img class="avatar floatL" src="<?php echo $this->_tpl_vars['tsConfig']['web']; ?>
/files/avatar/<?php echo $this->_tpl_vars['p']['p_user_pub']; ?>
_50.jpg">
        <strong class="nick">@<?php echo $this->_tpl_vars['p']['user_name']; ?>
</strong>
        <span class="timeago">Publicado <?php echo ((is_array($_tmp=$this->_tpl_vars['p']['p_date'])) ? $this->_run_mod_handler('fecha', true, $_tmp) : smarty_modifier_fecha($_tmp)); ?>
</span>
    </a>
    <?php if ($this->_tpl_vars['p']['p_body'] != ' '): ?><p class="body"><?php echo ((is_array($_tmp=$this->_tpl_vars['p']['p_body'])) ? $this->_run_mod_handler('quot', true, $_tmp) : smarty_modifier_quot($_tmp)); ?>
</p><?php endif; ?>
    <?php if ($this->_tpl_vars['p']['p_type'] != 1): ?>
    <div class="mvm">
        <?php if ($this->_tpl_vars['p']['p_type'] == 2): ?>
        <img src="<?php echo $this->_tpl_vars['p']['a_img']; ?>
"/>
        <?php elseif ($this->_tpl_vars['p']['p_type'] == 3): ?>
        <div class="uiLink">
            <div><a href="<?php echo $this->_tpl_vars['p']['a_url']; ?>
" target="_blank" class="a_blue"><strong><?php echo $this->_tpl_vars['p']['a_title']; ?>
</strong></a></div>
            <a href="<?php echo $this->_tpl_vars['p']['a_url']; ?>
" target="_blank" class="a_blue"><?php echo $this->_tpl_vars['p']['a_url']; ?>
</a>
        </div>
        <?php elseif ($this->_tpl_vars['p']['p_type'] == 4): ?>
        <a href="#" onclick="muro.load_atta('video','<?php echo $this->_tpl_vars['p']['a_url']; ?>
', this); return false;"class="uiVideoThumb">
            <img src="<?php echo $this->_tpl_vars['tsConfig']['images']; ?>
/video-icon.png" style="background-image:url(https://i1.ytimg.com/vi/<?php echo $this->_tpl_vars['p']['a_url']; ?>
/0.jpg);background-size: 100%;">           
            <i></i>
        </a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <div class="counters">
        <span><abbr id="tlikes_<?php echo $this->_tpl_vars['p']['pub_id']; ?>
"><?php echo $this->_tpl_vars['p']['p_likes']; ?>
</abbr> Me gusta</span>
        <span><?php echo $this->_tpl_vars['p']['p_comments']; ?>
 Comentarios</span>
    </div>
    <div id="error"></div>
    <div class="actions">
        <a class="shbtn shlike <?php if ($this->_tpl_vars['p']['mylike']): ?>ok<?php endif; ?>" onclick="muro.like_this(<?php echo $this->_tpl_vars['p']['pub_id']; ?>
)"></a>
        <a class="shbtn shcomment" href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/perfil/<?php echo $this->_tpl_vars['tsUser']->getUserName($this->_tpl_vars['p']['p_user']); ?>
?pid=<?php echo $this->_tpl_vars['p']['pub_id']; ?>
"></a>
        <a class="shbtn shreshout ok"></a>
    </div>
</li>
<?php endforeach; endif; unset($_from); ?>