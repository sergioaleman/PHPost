<?php /* Smarty version 2.6.26, created on 2024-08-10 15:40:54
         compiled from t.monitor.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'fecha', 't.monitor.tpl', 15, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<div class="blanco">
    <?php if ($this->_tpl_vars['tsAction'] == ''): ?>
        <h1 class="Titulo">&Uacute;ltimas <?php echo $this->_tpl_vars['tsData']['total']; ?>
 notificaciones</h1>
        <?php if ($this->_tpl_vars['tsData']['data']): ?>
        <ul class="monitor">
            <?php $_from = $this->_tpl_vars['tsData']['data']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['noti']):
?>
            <li <?php if ($this->_tpl_vars['noti']['unread'] > 0): ?>class="unread"<?php endif; ?>>
                <a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/perfil/<?php echo $this->_tpl_vars['noti']['user']; ?>
" class="avatar">
                    <img height="32" width="32" src="<?php echo $this->_tpl_vars['tsConfig']['web']; ?>
/files/avatar/<?php echo $this->_tpl_vars['noti']['avatar']; ?>
"/>
                </a>
                <div class="m_info">
                    <div class="m_autor">
                        <?php if ($this->_tpl_vars['noti']['total'] == 1): ?><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/perfil/<?php echo $this->_tpl_vars['noti']['user']; ?>
"><?php echo $this->_tpl_vars['noti']['user']; ?>
</a><?php endif; ?> 
                        <span title="<?php echo ((is_array($_tmp=$this->_tpl_vars['noti']['date'])) ? $this->_run_mod_handler('fecha', true, $_tmp) : smarty_modifier_fecha($_tmp)); ?>
" class="time"><?php echo ((is_array($_tmp=$this->_tpl_vars['noti']['date'])) ? $this->_run_mod_handler('fecha', true, $_tmp) : smarty_modifier_fecha($_tmp)); ?>
</span>
                    </div>
                    <div class="m_body">
                        <span class="monac_icons ma_<?php echo $this->_tpl_vars['noti']['style']; ?>
"></span><?php echo $this->_tpl_vars['noti']['text']; ?>

                        <a href="<?php echo $this->_tpl_vars['noti']['link']; ?>
"><?php echo $this->_tpl_vars['noti']['ltext']; ?>
</a>
                    </div>
                </div>
            </li>
            <?php endforeach; endif; unset($_from); ?>
        </ul>
        <?php else: ?>
        <div class="emptyData">No tienes notificaciones</div>
        <?php endif; ?>
    <?php endif; ?>
</div>                
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>