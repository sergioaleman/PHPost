<?php /* Smarty version 2.6.26, created on 2024-08-17 15:52:17
         compiled from t.php_files/p.muro.stream.tpl */ ?>
1:
<?php if ($this->_tpl_vars['tsMuro']['total']): ?><div id="total_pubs" val="<?php echo $this->_tpl_vars['tsMuro']['total']; ?>
"></div><?php endif; ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'modules/m.perfil_muro_story.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>