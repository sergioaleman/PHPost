<?php /* Smarty version 2.6.26, created on 2024-08-19 12:50:50
         compiled from sections/main_header.tpl */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title><?php echo $this->_tpl_vars['tsTitle']; ?>
</title>
<link href="<?php echo $this->_tpl_vars['tsConfig']['tema']['t_url']; ?>
/estilo.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->_tpl_vars['tsConfig']['tema']['t_url']; ?>
/header.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="<?php echo $this->_tpl_vars['tsConfig']['images']; ?>
/favicon.ico" type="image/x-icon" />
<link rel="apple-touch-icon" href="https://m.infoudo.com.ve/apple-touch.png">
<script src="<?php echo $this->_tpl_vars['tsConfig']['js']; ?>
/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo $this->_tpl_vars['tsConfig']['js']; ?>
/jquery.plugins.js" type="text/javascript"></script>
<script src="<?php echo $this->_tpl_vars['tsConfig']['js']; ?>
/jquery.autosize.min.js" type="text/javascript"></script>
<script src="<?php echo $this->_tpl_vars['tsConfig']['js']; ?>
/jquery.lazyload.js" type="text/javascript"></script>
<script src="<?php echo $this->_tpl_vars['tsConfig']['js']; ?>
/acciones.js" type="text/javascript"></script>
<script src="<?php echo $this->_tpl_vars['tsConfig']['js']; ?>
/funciones.js" type="text/javascript"></script>
<script type="text/javascript">
// <?php echo '
var global_data={
// '; ?>

	user_key:'<?php echo $this->_tpl_vars['tsUser']->uid; ?>
',
	user_nick:'<?php echo $this->_tpl_vars['tsUser']->nick; ?>
',
	postid:'<?php echo $this->_tpl_vars['tsPost']['post_id']; ?>
',
	fotoid:'<?php echo $this->_tpl_vars['tsFoto']['foto_id']; ?>
',
	img:'<?php echo $this->_tpl_vars['tsConfig']['tema']['t_url']; ?>
/',
	web:'<?php echo $this->_tpl_vars['tsConfig']['web']; ?>
',
	url:'<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
',
	domain:'<?php echo $this->_tpl_vars['tsConfig']['domain']; ?>
',
    s_title: '<?php echo $this->_tpl_vars['tsConfig']['titulo']; ?>
',
    s_slogan: '<?php echo $this->_tpl_vars['tsConfig']['slogan']; ?>
'
// <?php echo '
};
var scrollContinue = true;
// '; ?>

</script>
<link rel="publisher" href="https://www.facebook.com/infoudomonagas1">

<link href="/style/estilo.css" rel="stylesheet" type="text/css" media="screen">
<script language="JavaScript" src="https://m.infoudo.com.ve/js/cookies.js"></script>

<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/1.0.9/cookieconsent.min.js"></script>

<script language="JavaScript" src="https://m.infoudo.com.ve/js/snow2.js"></script>

<meta name="theme-color" content="#d4eefd">    

<!--  Google Addsense  -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2139263390076630"
     crossorigin="anonymous"></script>
     
  <meta name="google-adsense-account" content="ca-pub-2139263390076630">
</head>
<body>
<nav><div class="container">
<a href="https://m.infoudo.com.ve" class="main">InfoUDO!</a>
<input id="bmenu" class="burgercheck" type="checkbox">
<label for="bmenu" class="burgermenu"><i class="fa fa-search"></i></label><div class="menu"><form action="https://www.google.com/search"><input type="search" name="q" placeholder="buscar" value /><input type="hidden" name="as_sitesearch" value="infoudo.com.ve"></form></div><div class="social">
<a href="https://m.facebook.com/infoudomonagas1"><i class="fa fa-facebook"></i></a>
<a href="https://mobile.twitter.com/infoudomon/"><i class="fa fa-twitter"></i></a>
<a href="https://plus.google.com/u/0/b/118031983502145084990/+Infoudo/" class="s-none"><i class="fa fa-google-plus"></i></a>
<a href="http://feeds.feedburner.com/Infoudo" class="s-none"><i class="fa fa-rss"></i></a>
<a href="https://feedburner.google.com/fb/a/mailverify?uri=infoudo&amp;loc=es_ES" class="s-none" target="_blank"><i class="fa fa-send"></i></a></div></div></nav>

<div id="brandday">   
	<div id="sidebar">
        <ul class="menu">
        	<?php if ($this->_tpl_vars['tsUser']->is_member): ?>
            <li class="<?php if ($this->_tpl_vars['tsPage'] == 'perfil'): ?>active<?php endif; ?>"><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/perfil/<?php echo $this->_tpl_vars['tsUser']->nick; ?>
"><img class="avatar" src="<?php echo $this->_tpl_vars['tsConfig']['web']; ?>
/files/avatar/<?php echo $this->_tpl_vars['tsUser']->uid; ?>
_50.jpg">@<?php echo $this->_tpl_vars['tsUser']->nick; ?>
</a></li>
            <li class="<?php if ($this->_tpl_vars['tsPage'] == 'monitor'): ?>active<?php endif; ?> menu_icon monitor"><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/monitor/">Notificaciones<?php if ($this->_tpl_vars['tsNots'] > 0): ?><span class="popup"><?php echo $this->_tpl_vars['tsNots']; ?>
</span><?php endif; ?></a></li>
            <li class="<?php if ($this->_tpl_vars['tsPage'] == 'mensajes'): ?>active<?php endif; ?> menu_icon mensajes"><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/mensajes/">Mensajes<?php if ($this->_tpl_vars['tsMPs'] > 0): ?><span class="popup"><?php echo $this->_tpl_vars['tsMPs']; ?>
</span><?php endif; ?></a></li>
            <li class="<?php if ($this->_tpl_vars['tsPage'] == 'favoritos'): ?>active<?php endif; ?> menu_icon favoritos radius"><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/favoritos/">Favoritos</a></li>
            <li class="separator"></li>            
            <li class="<?php if ($this->_tpl_vars['tsPage'] == 'portal'): ?>active<?php endif; ?> menu_icon mi"><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/portal/">Mi <?php echo $this->_tpl_vars['tsConfig']['titulo']; ?>
</a></li>
            <?php endif; ?>
            <li class="<?php if ($this->_tpl_vars['tsPage'] == 'home'): ?>active<?php endif; ?> menu_icon posts"><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/posts/">Posts recientes</a></li>
            <?php if ($this->_tpl_vars['tsConfig']['c_fotos_private'] == '1'): ?><?php else: ?>
            <li class="<?php if ($this->_tpl_vars['tsPage'] == 'fotos'): ?>active<?php endif; ?> menu_icon fotos"><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/fotos/">Fotos</a></li>
            <?php endif; ?>
            <li class="<?php if ($this->_tpl_vars['tsPage'] == 'tops'): ?>active<?php endif; ?> radius menu_icon tops"><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/top/posts/">TOP Posts</a></li>
            <li class="<?php if ($this->_tpl_vars['tsPage'] == 'tops'): ?>active<?php endif; ?> radius menu_icon directorio"><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/posts/Infoudo/10/Directorio.html">Directorio</a></li>
            <li class="separator"></li>
            <?php if ($this->_tpl_vars['tsUser']->is_member): ?>
            <li class="menu_icon salir radius"><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/login-salir.php">Salir</a></li>
            <?php else: ?>
            <li class="<?php if ($this->_tpl_vars['tsPage'] == 'registro'): ?>active<?php endif; ?> menu_icon registro"><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/registro/">Registrarme</a></li>
            <li class="<?php if ($this->_tpl_vars['tsPage'] == 'login'): ?>active<?php endif; ?> menu_icon login radius"><a href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
/login/">Ingresar</a></li>
            <?php endif; ?>
        </ul>
    </div>
    <div id="maincontainer">    	
        <header>
            <a class="menu_toggle" onclick="menu_toggle(1)"><?php if ($this->_tpl_vars['tsNots']+$this->_tpl_vars['tsMPs'] > 0): ?><span class="popup"><?php echo $this->_tpl_vars['tsNots']+$this->_tpl_vars['tsMPs']; ?>
</span><?php endif; ?></a>
            <a class="logo" href="<?php echo $this->_tpl_vars['tsConfig']['url']; ?>
"><?php echo $this->_tpl_vars['tsConfig']['titulo']; ?>
</a>
        </header>
        <div class="modal modal-share">
            <p>&iquest;Quieres compartir este post con tus seguidores?</p>
            <button onclick="modal.action('share')" class="btn_blue">Compartir</button>
            <button onclick="modal.cerrar()">Cancelar</button>
        </div>
        <div class="modal modal-fav">
            <p>&iquest;Quieres agregar este post a favoritos?</p>
            <button onclick="modal.action('fav')" class="btn_blue">Aceptar</button>
            <button onclick="modal.cerrar()">Cancelar</button>
        </div>
        <div class="modal modal-alerta">
            <p>Error</p>
            <button onclick="modal.cerrar(false, '#total_shares')" class="btn_blue">Aceptar</button>
        </div>
        <div class="modal modal-home">
            <p>Ok</p>
            <button onclick="location.href=global_data.url" class="btn_blue">Aceptar</button>
        </div>
        <div id="cuerpo">
        <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/head_noticias.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>