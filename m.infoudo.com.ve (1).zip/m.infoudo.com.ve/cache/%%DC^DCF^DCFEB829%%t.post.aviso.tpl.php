<?php /* Smarty version 2.6.26, created on 2024-08-14 16:38:47
         compiled from t.post.aviso.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<h1 class="Titulo" align="center">Opps!</h1>
<div class="modal modal-alerta" style="display: block;">
<p><?php echo $this->_tpl_vars['tsAviso']['1']; ?>
</p>
<button onclick="history.back()" <?php if (! $this->_tpl_vars['tsAviso']['but']): ?>class="btn_blue"<?php endif; ?>>Volver</button>
</div>
                
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>