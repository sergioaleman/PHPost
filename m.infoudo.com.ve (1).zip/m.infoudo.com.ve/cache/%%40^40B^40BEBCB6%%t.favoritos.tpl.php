<?php /* Smarty version 2.6.26, created on 2024-08-10 15:41:04
         compiled from t.favoritos.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<script type="text/javascript">
var totalPosts = <?php echo $this->_tpl_vars['tsPosts']['total']; ?>
;
//<?php echo '
$(function(){
	$(window).scroll(function(){
		var wintop = $(window).scrollTop(), docheight = $(document).height(), winheight = $(window).height();
		var scrolltrigger = 0.95;
		if ((wintop / (docheight - winheight)) > scrolltrigger) {
			if(scrollContinue) {$(\'.load-more\').click()} else {return}
		}
	 });
	 $("img.plazyload").lazyload();
});
//'; ?>

</script>
<h1 class="Titulo">Posts favoritos<span class="floatR"><?php echo $this->_tpl_vars['tsPosts']['stats_posts']; ?>
</span></h1>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_submenu.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php if ($this->_tpl_vars['tsPosts']['data']): ?>
<ul class="posts">
    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'modules/m.home_last_posts.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
</ul>
<?php else: ?>
<li class="emptyData">No haz agregado posts en tus favoritos.</li>
<?php endif; ?>
<?php if ($this->_tpl_vars['tsPosts']['total'] == 25): ?>
<div class="load-more" onclick="load_more('favs')">Ver m&aacute;s</div>
<?php endif; ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>