<?php /* Smarty version 2.6.26, created on 2024-08-10 08:02:37
         compiled from t.post_privado.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<div class="titulo_post">
	<h1><?php echo $this->_tpl_vars['tsPost']['1']; ?>
</h1>
</div>
<div id="login_error"></div>
<form id="login" class="box" method="post" action="javascript:login_ajax()">
	<div class="post_privado">
        <h2>Este post es privado</h2>
        <p>Solo los usuarios registrados de <?php echo $this->_tpl_vars['tsConfig']['titulo']; ?>
 pueden acceder.</p>
    </div>
    <input type="text" id="nickname" class="input-text" name="nick" placeholder="Usuario">
    <input type="password" id="password" class="input-text" name="pass" placeholder="Contrase&ntilde;a">
    <div class="controls clearfix">
    	<input type="submit" value="Ingresar">
    </div>
</form>
<div class="line_separator"></div>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>