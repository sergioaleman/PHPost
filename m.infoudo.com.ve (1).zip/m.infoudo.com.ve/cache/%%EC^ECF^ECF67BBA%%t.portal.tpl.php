<?php /* Smarty version 2.6.26, created on 2024-08-10 09:12:42
         compiled from t.portal.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['tsConfig']['js']; ?>
/perfil.js"></script>
<script type="text/javascript">
muro.stream.total = <?php echo $this->_tpl_vars['tsMuro']['total']; ?>
;
//<?php echo '
$(function(){
	$(window).scroll(function(){
		var wintop = $(window).scrollTop(), docheight = $(document).height(), winheight = $(window).height();
		var scrolltrigger = 0.95;
		if ((wintop / (docheight - winheight)) > scrolltrigger) {
			if(scrollContinue) {$(\'.load-more\').click()} else {return false}
		}
	 });
});
//'; ?>

</script>
<h1 class="Titulo">Miembros<span class="floatR"><?php echo $this->_tpl_vars['tsMuro']['stats_miembros']; ?>
</span></h1>
<input type="hidden" id="info" value="<?php echo $this->_tpl_vars['tsUser']->uid; ?>
" />			
<div class="box_comentario">
    <div class="caja_text" style="padding-left: 0;">
        <textarea placeholder="&iquest;Qu&eacute; est&aacute;s pensando?" id="body_comment"></textarea>
    </div>
    <div class="caja_boton">
        <img id="comment_loading" src="<?php echo $this->_tpl_vars['tsConfig']['images']; ?>
/loading.gif">
        <input type="button" id="add_comment" value="Comentar" class="btn_blue" onclick="muro.stream.compartir()" />
    </div>
    <div id="error"></div>
</div>
<ul class="shouts">
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'modules/m.perfil_muro_story.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>                         
</ul>
<?php if ($this->_tpl_vars['tsMuro']['total'] >= 10): ?>
<div class="load-more" onclick="muro.stream.loadMore('portal'); return false;">Publicaciones m&aacute;s antiguas</div>
<?php elseif ($this->_tpl_vars['tsMuro']['total'] == 0): ?>
<div class="emptyData">No hay publicaciones</div>
<?php endif; ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'sections/main_footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>