<?php if ( ! defined('TS_HEADER')) exit('No se permite el acceso directo al script');

date_default_timezone_set("America/Caracas");
setlocale(LC_TIME, 'es_VE.UTF-8','esp');

/**
 * Funciones globales
 *
 * @name    c.core.php
 * @author  PHPost Team
 */
class tsCore {
    
	var $settings;		// CONFIGURACIONES DEL SITIO	
	var $querys = 0;	// CONSULTAS
    
	// INSTANCIA DE LA CLASE
	public static function &getInstance(){
		static $instance;
		
		if( is_null($instance) ){
			$instance = new tsCore();
    	}
		return $instance;
	}

	function tsCore()
    {
		// CARGANDO CONFIGURACIONES
		$this->settings = $this->getSettings();
		$this->settings['web'] = $this->settings['url'];
		$this->settings['url'] = $this->settings['mobile'];
		$this->settings['domain'] = str_replace('http://','',$this->settings['url']);
		$this->settings['categorias'] = $this->getCategorias();
        $this->settings['default'] = $this->settings['web'].'/themes/default';
		$this->settings['tema'] = $this->getTema();
		$this->settings['tema_web'] = $this->settings['tema']['web'];
		$this->settings['images'] = $this->settings['tema']['t_url'].'/images';
        $this->settings['css'] = $this->settings['tema']['t_url'].'/css';
		$this->settings['js'] = $this->settings['tema']['t_url'].'/js';
        //
        if($_GET['do'] == 'portal' || $_GET['do'] == 'posts') $this->settings['news'] = $this->getNews();
		# Mensaje del instalador y pendientes de moderaci?n #
		$this->settings['install'] = $this->existinstall();
		$this->settings['novemods'] = $this->getNovemods();
	}
	
	/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/	
	/*
		getSettings() :: CARGA DESDE LA DB LAS CONFIGURACIONES DEL SITIO
	*/
	function getSettings()
    {
		$query = mysql_query('SELECT * FROM w_configuracion');
		return mysql_fetch_assoc($query);
	}
	
	function getNovemods()
    {
        $datos = mysql_fetch_assoc(mysql_query('SELECT (SELECT count(post_id) FROM p_posts WHERE post_status = \'3\') as revposts, (SELECT count(cid) FROM p_comentarios WHERE c_status = \'1\' ) as revcomentarios, (SELECT count(DISTINCT obj_id) FROM w_denuncias WHERE d_type = \'1\') as repposts, (SELECT count(DISTINCT obj_id) FROM w_denuncias WHERE d_type = \'2\') as repmps, (SELECT count(DISTINCT obj_id) FROM w_denuncias WHERE d_type = \'3\') as repusers, (SELECT count(DISTINCT obj_id) FROM w_denuncias  WHERE d_type = \'4\') as repfotos, (SELECT count(susp_id) FROM u_suspension) as suspusers, (SELECT count(post_id) FROM p_posts WHERE post_status = \'2\') as pospelera, (SELECT count(foto_id) FROM f_fotos WHERE f_status = \'2\') as fospelera'));
		$datos['total'] = $datos['repposts'] + $datos['repfotos'] + $datos['repmps'] + $datos['repusers'] + $datos['revposts'] + $datos['revcomentarios'];
		return $datos;  
	}
	/*
		getCategorias()
	*/
	function getCategorias()
    {
		// CONSULTA
		$query = mysql_query('SELECT cid, c_orden, c_nombre, c_seo, c_img FROM p_categorias ORDER BY c_orden');
		// GUARDAMOS
		$categorias = result_array($query);
        //
        return $categorias;
	}
	/*
		getTema()
	*/
	function getTema()
    {
		//
		$query = mysql_query('SELECT * FROM w_temas WHERE tid = '.$this->settings['tema_id'].' LIMIT 1');
		//
		$data = mysql_fetch_assoc($query);
		//$data['t_path'] = 'default';
        $data['t_url'] = $this->settings['url'] . '/themes/' . $data['t_path'];
		$data['web'] = $this->settings['web'] . '/themes/' . $data['t_path'];
		//
		return $data;
	}
	/*
        getNews()
    */
    function getNews()
    {
        //
		$query = mysql_query('SELECT not_body FROM w_noticias WHERE not_active = \'1\' ORDER by RAND()');
		while($row = mysql_fetch_assoc($query)){
		  $row['not_body'] = $this->parseBBCode($row['not_body'],'news');
          $data[] = $row;
		}
        //
        return $data;
    }
	/*
	 * Sacar imagen del post
	 * si hay mas de una imagenen, tomamos la 2 (casi siempre la 1 es de "bienvenido")
	 */
	function extraer_img($texto, $id) {
		// del tipo [img=imagen] o [img]imagen[/img]
		preg_match_all('/(\[img(\=|\]))((http|https)?(\:\/\/)?([^\<\>[:space:]]+)\.(jpg|jpeg|png|gif))(\]|\[\/img\])/i', $texto, $imgs);
		$total = count($imgs[3]);
		// Sacamos la mejor imagen posible ._.
		$img = (count($imgs[3]) > 1) ? $imgs[3][1] : $imgs[3][0];	
		if(empty($img)) $img = false;
		//
		return $img;
	}
	
	//COMPROBACIONES DE LA EXISTENCIA DEL INSTALADOR O ACTUALIZADOR
	
	function existinstall() 
    {
		$install_dir = TS_ROOT . '/install/';
		$upgrade_dir = TS_ROOT . '/upgrade/';
		if(is_dir($install_dir)) return '<div class="emptyData">Por favor, elimine la carpeta <b>install</b></div>';		
		if(is_dir($upgrade_dir)) return '<div class="emptyData">Por favor, elimine la carpeta <b>upgrade</b></div>';
	}
    
    // FUNCI?N CONCRETA PARA CENSURAR
	
	function parseBadWords($c, $s = FALSE) 
    {
        $q = result_array(mysql_query('SELECT word, swop, method, type FROM w_badwords '.($s == true ? '' : ' WHERE type = \'0\'')));
        
        foreach($q AS $badword) 
        {
        $c = str_ireplace((empty($badword['method']) ? $badword['word'] : $badword['word'].' '),($badword['type'] == 1 ? '<img class="qtip" title="'.$badword['word'].'" src="'.$badword['swop'].'" align="absmiddle"/>' : $badword['swop'].' '),$c);
        }
        return $c;
	}        
	
	/*
		setLevel($tsLevel) :: ESTABLECE EL NIVEL DE LA PAGINA | MIEMBROS o VISITANTES
	*/
	function setLevel($tsLevel, $msg = false){
		global $tsUser;
		
		// CUALQUIERA
		if($tsLevel == 0) return true;
		// SOLO VISITANTES
		elseif($tsLevel == 1) {
			if($tsUser->is_member == 0) return true;
			else {
				if($msg) $mensaje = 'Esta pagina solo es vista por los visitantes.';
				else $this->redirect('/');
			}
		}
		// SOLO MIEMBROS
		elseif($tsLevel == 2){
			if($tsUser->is_member == 1) return true;
			else {
				if($msg) $mensaje = 'Para poder ver esta pagina debes iniciar sesi&oacute;n.';
				else $this->redirect('/login/?r='.$this->currentUrl());
			}
		}
		// SOLO MODERADORES
		elseif($tsLevel == 3){
			if($tsUser->is_admod || $tsUser->permisos['moacp']) return true;
			else {
				if($msg) $mensaje = 'Estas en un area restringida solo para moderadores.';
				else $this->redirect('/login/?r='.$this->currentUrl());
			}
		}
		// SOLO ADMIN
		elseif($tsLevel == 4) {
			if($tsUser->is_admod == 1) return true;
			else {
				if($msg) $mensaje = 'Estas intentando algo no permitido.';
				else $this->redirect('/login/?r='.$this->currentUrl());
			}
		}
		//
		return array('titulo' => 'Error', 'mensaje' => $mensaje, 'but' => 'Inicio');
	}

	/*
		redirect($tsDir)
	*/
	function redirectTo($tsDir){
		$tsDir = urldecode($tsDir);
		header("Location: $tsDir");
		exit();
	}
    /*
        getDomain()
    */
    function getDomain(){
        $domain = explode('/',str_replace('http://','',$this->settings['url']));
        if(is_array($domain)) {
        $domain = explode('.',$domain[0]);
        } else $domain = explode('.',$domain);
        //
        $t = count($domain);
        $domain = $domain[$t - 2].'.'.$domain[$t - 1];
        //
        return $domain;
    }
	/*
		currentUrl()
	*/
	function currentUrl(){
		$current_url_domain = $_SERVER['HTTP_HOST'];
		$current_url_path = $_SERVER['REQUEST_URI'];
		$current_url_querystring = $_SERVER['QUERY_STRING'];
		$current_url = "http://".$current_url_domain.$current_url_path;
		$current_url = urlencode($current_url);
		return $current_url;
	}
	/*
        getPagination($total, $per_page)
    */
    function getPagination($total, $per_page = 10){
        // PAGINA ACTUAL
        $page = empty($_GET['page']) ? 1 : (int) $_GET['page'];
        // NUMERO DE PAGINAS
        $num_pages = ceil($total / $per_page);
        // ANTERIOR
        $prev = $page - 1;
        $pages['prev'] = ($page > 0) ? $prev : 0;
        // SIGUIENTE 
        $next = $page + 1;
        $pages['next'] = ($next <= $num_pages) ? $next : 0;
        // LIMITE DB
        $pages['limit'] = (($page - 1) * $per_page).','.$per_page; 
        // TOTAL
        $pages['total'] = $total;
        //
        return $pages;
    }
	/*
		setJSON($tsContent)
	*/
	function setJSON($data, $type = 'encode'){
		require_once(TS_EXTRA . 'JSON.php');	// INCLUIMOS LA CLASE
		$json = new Services_JSON;	// CREAMOS EL SERVICIO
        if($type == 'encode') return $json->encode($data);
        elseif($type == 'decode') return $json->decode($data);            
	}
	/*
		setSecure()
	*/
	public function setSecure($var, $xss = FALSE)
    {
        $var = mysql_real_escape_string(function_exists('magic_quotes_gpc') ? stripslashes($var) : $var);
        /**
        if ($xss)
        {
        $var = htmlspecialchars($var, ENT_NOQUOTES,'UTF-8');
        }*/
     return $var;
    }
	
    /*
        antiFlood()
    */
    public function antiFlood($print = true, $type = 'post', $msg = '')
    {
        global $tsUser;
        //
        $now = time();
        $msg = empty($msg) ? 'No puedes realizar tantas acciones en tan poco tiempo.' : $msg;
        //
        $limit = $tsUser->permisos['goaf'];
        $resta = $now - $_SESSION['flood'][$type];
        if($resta < $limit) {
            $msg = '0: '.$msg.' Int&eacute;ntalo en '.($limit - $resta).' segundos.';
            // TERMINAR O RETORNAR VALOR
            if($print) die($msg);
            else return $msg;
        }
        else {
            // ANTIFLOOD
            if(empty($_SESSION['flood'][$type])) {
                $_SESSION['flood'][$type] = time();
            } else $_SESSION['flood'][$type] = $now;
            // TODO BIEN
            return true;
        }
    }
	
	/*
		setSEO($string, $max) $max : MAXIMA CONVERSION
		: URL AMIGABLES
	*/
	function setSEO($string, $max = false) {
		// ESPA?OL
		$espanol = array('?','?','?','?','?','?');
		$ingles = array('a','e','i','o','u','n');
		// MINUS
		$string = str_replace($espanol,$ingles,$string);
		$string = trim($string);
		$string = trim(preg_replace('/[^ A-Za-z0-9_]/', '-', $string));
		$string = preg_replace('/[ \t\n\r]+/', '-', $string);
		$string = str_replace(' ', '-', $string);
		$string = preg_replace('/[ -]+/', '-', $string);
		//
		if($max) {
			$string = str_replace('-','',$string);
			$string = strtolower($string);
		}
		//
		return $string;
	}
	/*
		parseBBCode($bbcode)
	*/
	function parseBBCode($bbcode, $type = 'normal'){
        // CLASS BBCode
        include_once(TS_EXTRA . 'bbcode.inc.php');
        $parser =& BBCode::getInstance();
        switch($type){
            // NORMAL
            case 'normal':
                // RESTRICTIONS
                $parser->restriction = array('url', 'code', 'quote', 'quotePHPost', 'font', 'size', 'color', 'img', 'b', 'i', 'u', 'align', 'spoiler', 'swf', 'goear', 'hr', 'li');
                // CONVERTIMOS
                $html = $parser->parseString($bbcode);
                // SMILES
                $html = $parser->parseSmiles($html, $this->settings['default'].'/images/smiles/');
                // MENCIONES
                $html = $this->setMenciones($html);
            break;
            // FIRMA
            case 'firma':
                // BBCodes permitidos
                $parser->restriction = array('url', 'font', 'size', 'color', 'img', 'b', 'i', 'u', 'align', 'spoiler');
                // CONVERTIMOS
                $html = $parser->parseString($bbcode);
            break;
            // NOTICIAS
            case 'news':
                // BBCodes permitidos
                $parser->restriction = array('url', 'b', 'i', 'u');
                // CONVERTIMOS
                $html = $parser->parseString($bbcode);
                // SMILES
                $html = $parser->parseSmiles($html, $this->settings['default'].'/images/smiles/');                
            break;
            // SOLO SMILES
            case 'smiles':
                $parser->restriction = array('url', 'code', 'quote', 'quotePHPost', 'font', 'size', 'color', 'img', 'b', 'i', 'u', 'align', 'spoiler', 'swf', 'goear', 'hr', 'li');
                // SMILES
                $html = $parser->parseSmiles($bbcode, $this->settings['default'].'/images/smiles/');
                // MENCIONES
                $html = $this->setMenciones($html);
            break;
        }
        //
        return $html;
	}
    /**
     * @name setMenciones
     * @access public
     * @param string
     * @return string
     * @info PONE LOS LINKS A LOS MENCIONADOS
     */
    public function setMenciones($html){
        # GLOBALES
        global $tsUser;
        # HACK
        $html = $html.' ';
        # BUSCAMOS A USUARIOS
        preg_match_all('/\B@([a-zA-Z0-9_-]{4,16}+)\b/',$html, $users);
        $menciones = $users[1];
        # VEMOS CUALES EXISTEN
        foreach($menciones as $key => $user){
            if(strtolower($user) != strtolower($tsUser->nick)) {
                $uid = $tsUser->getUserID($user);
                if(!empty($uid)) {
                    $find = '@'.$user.' ';
                    $replace = '@<a href="'.$this->settings['url'].'/perfil/'.$user.'" class="hovercard" uid="'.$uid.'">'.$user.'</a> ';
                    $html = str_replace($find, $replace, $html);
                }
            }
        }
        # RETORNAMOS
        return $html;
    }
    /*
        parseSmiles($st)
    */
    public function parseSmiles($bbcode){
        return $this->parseBBCode($bbcode, 'smiles');
    }
	/*
		parseBBCodeFirma($bbcode)
	*/
	function parseBBCodeFirma($bbcode){
	   return $this->parseBBCode($bbcode, 'firma');
	}
	/*
		setHace()
	*/
	function setHace($fecha, $show = false){
		$fecha = $fecha; 
		$ahora = time();
		$tiempo = $ahora-$fecha; 
		if($fecha <= 0){
			return 'Nunca';
		}
		elseif(round($tiempo / 31536000) <= 0){ 
			if(round($tiempo / 2678400) <= 0){ 
				 if(round($tiempo / 86400) <= 0){ 
					 if(round($tiempo / 3600) <= 0){ 
						if(round($tiempo / 60) <= 0){ 
							if($tiempo <= 60){ $hace = 'instantes'; } 
						} else  { 
							$can = round($tiempo / 60); 
							if($can <= 1) {    $word = 'minuto'; } else { $word = 'minutos'; } 
							$hace = $can. " ".$word; 
						} 
					} else { 
						$can = round($tiempo / 3600); 
						if($can <= 1) {    $word = 'hora'; } else {    $word = 'horas'; } 
						$hace = $can. " ".$word; 
					} 
				} else  { 
					$can = round($tiempo / 86400); 
					if($can <= 1) {    $word = 'd&iacute;a'; } else {    $word = 'd&iacute;as'; } 
					$hace = $can. " ".$word;
				} 
			} else  { 
				$can = round($tiempo / 2678400);  
				if($can <= 1) {    $word = 'mes'; } else { $word = 'meses'; } 
				$hace = $can. " ".$word; 
			}
		 }else  {
			$can = round($tiempo / 31536000); 
			if($can <= 1) {    $word = 'a&ntilde;o';} else { $word = 'a&ntilde;os'; } 
			$hace = $can. " ".$word; 
		 }
		 //
		 if($show == true) return 'Hace '.$hace;
		 else return $hace;
	}
	/*
		getUrlContent($tsUrl)
	*/
	function getUrlContent($tsUrl){
	   // USAMOS CURL O FILE
	   if(function_exists('curl_init')){
    		// User agent
    		$useragent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; es-ES; rv:1.9) Gecko/2008052906 Firefox/3.0';
    		//Abrir conexion  
    		$ch = curl_init();  
    		curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    		curl_setopt($ch,CURLOPT_URL,$tsUrl);
    		curl_setopt ($ch, CURLOPT_TIMEOUT, 60);
    		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    		$result = curl_exec($ch);
    		curl_close($ch); 
        } else {
            $result = @file_get_contents($tsUrl);
        }
		return $result;
	}
	/*
		getUserCountry()
	*/
	function getUserCountry(){
		//
		require('../ext/geoip.inc.php');
		$abir_bd = geoip_open('../ext/GeoIP.dat',GEOIP_STANDARD);
		$country = geoip_country_code_by_addr($abir_bd, $_SERVER['REMOTE_ADDR']);
		geoip_close($abir_bd); 
		//
		return $country;
	}
    /*
        getIP
    */
    function getIP(){
	   if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) $ip = getenv('HTTP_CLIENT_IP');	
	   elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) $ip = getenv('HTTP_X_FORWARDED_FOR');
	   elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) $ip = getenv('REMOTE_ADDR');
	   elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) $ip = $_SERVER['REMOTE_ADDR'];
	   else $ip = 'unknown';
	   return $this->setSecure($ip);
    }
	/*
		Encriptador KOX
		Encriptacion simple by JNeutron :D
		koxEncode($tsData,$kox_1)
	*/
	function koxEncode($tsData,$kox_l = NULL){
		$KOXkey = array(
			'a' => '0','b' => 1,'c' => 2,'d' => 3,'e' => 4,'f' => 5,'g' => 6,'h' => 7,'i' => 8,'j' => 9,
			'k' => 'z','l' => 'y','m' => 'x','n' => 'w','o' => 'v','p' => 'u','q' => 't','r' => 's',
			's' => 'r','t' => 'q','u' => 'p','v' => 'o','w' => 'n','x' => 'm','y' => 'l','z' => 'k',
			'0' => 'j',1 => 'i',2 => 'h',3 => 'g',4 => 'f',5 => 'e',6 => 'd',7 => 'c',8 => 'b',9 => 'a',
			'@' => '{', '.' => '}',
		);
		if(!$kox_l || $kox_l > 9) $kox_l = rand(1,9);
		$kox_n = $KOXkey[$kox_l];
		$kox_s = strlen($tsData);
		for($i=0;$i<$kox_s;$i++){
			$kox_c = $tsData[$i];
			for($j=0;$j<$kox_l;$j++){
				if($KOXkey[$kox_c] != '') $kox_c = $KOXkey[$kox_c];
				else $kox_c = $tsData[$i];
			}
			$kox_key .= $kox_c;
		}
		return $kox_key.$kox_n;
	}
	/*
		By JNeutron
		koxDecode($tsKey)
	*/
	function koxDecode($tsKey){
		$KOXkey = array(
			'0' => 'a',1 => 'b',2 => 'c',3 => 'd',4 => 'e',5 => 'f',6 => 'g',7 => 'h',8 => 'i',9 => 'j',
			'z' => 'k','y' => 'l','x' => 'm','w' => 'n','v' => 'o','u' => 'p','t' => 'q','s' => 'r',
			'r' => 's','q' => 't','p' => 'u','o' => 'v','n' => 'w','m' => 'x','l' => 'y','k' => 'z',
			'j' => '0','i' => 1,'h' => 2,'g' => 3,'f' => 4,'e' => 5,'d' => 6,'c' => 7,'b' => 8,'a' => 9,
			'{' => '@', '}' => '.',
		);
		$kox_s = strlen($tsKey);
		$kox_l = $tsKey[$kox_s-1];
		$kox_n = $KOXkey[$kox_l];
		for($i=0;$i<$kox_s-1;$i++){
			$kox_c = $tsKey[$i];
			for($j=$kox_n;$j>0;$j--){
				if($KOXkey[$kox_c] != '') $kox_c = $KOXkey[$kox_c];
				else $kox_c = $kox_c;
			}
			$kox_txt .= $kox_c;
		}
		return $kox_txt;
	}
	/* 
		getIUP()
	*/
	function getIUP($array, $prefix = ''){
		// NOMBRE DE LOS CAMPOS
		$fields = array_keys($array);
		// VALOR PARA LAS TABLAS
		$valores = array_values($array);
		// NUMERICOS Y CARACTERES
		foreach($valores as $i => $val) {
		  $sets[$i] = $prefix.$fields[$i]." = '".$this->setSecure($val)."'"; // Version: 1.1.500.8
		}
		$values = implode(', ',$sets);
		//
		return $values;
	}
	
	/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
	
	
}