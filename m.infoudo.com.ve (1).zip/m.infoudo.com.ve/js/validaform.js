
function valida_envia(){

	//valido el nombre
	if (document.citaform.nombre.value.length==0){
		alert("Debe escribir un nombre")
		document.citaform.nombre.focus()
		return 0;
	}
	
	//valido el ciudad
	if (document.citaform.ciudad.value.length==0){
		alert("Debe introducir una ciudad")
		document.citaform.ciudad.focus()
		return 0;
	}
	
	//valido el telefono
	if (document.citaform.telefono.value.length < 11){
		alert("Debe ingresasr un tel�fono fijo, incluyendo el c�digo de �rea. Ejemplo: 02418999999")
		document.citaform.telefono.focus()
		return 0;
	}	

	//valido cita
	if (document.citaform.orderdate.value.length==0){
		alert("Debe introducir una fecha")
		document.citaform.orderdate.focus()
		return 0;
	}
	
	//el formulario se envia
	document.citaform.submit();
}