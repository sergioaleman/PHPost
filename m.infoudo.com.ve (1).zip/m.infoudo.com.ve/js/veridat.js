colorMal="#ffffcc"; 
    colorBien="white"; 
 
    regla=new Array() 
 
    regla[0]="valor.length<3"; 
    regla[1]="valor.lastIndexOf('@')!=valor.indexOf('@') || valor.indexOf('@')<2 || valor.lastIndexOf('.')<valor.length-4 || valor.lastIndexOf('.')>valor.length-3"; 
 	regla[2]=""; 
 	regla[3]="valor.length<3";
 	regla[4]="valor.length<3";
 	
    mensaje=new Array() 
 
 
    mensaje[0]="*Introduzca un nombre"; 
    mensaje[1]="*Introduzca un correo v&aacute;lido"; 
	mensaje[2]="";
	mensaje[3]="*Introduzca un asunto";
	mensaje[4]="*Deje un mensaje";
	
    function comprobar(){  
    errores="";  
    mensaje4=""; 
    for(a=0;a<regla.length;a++){  
    valor=document.forms[0].elements[a].value;  
    if(eval(regla[a])){ 
    mensaje4=(mensaje[a])?mensaje[a]:"Por favor, rellene el campo con un email correcto "+document.forms[0].elements[a].name; 
    errores+=mensaje4+"<br>";  
    document.forms[0].elements[a].style.background=colorMal;}  
    else{document.forms[0].elements[a].style.background=colorBien;}  
    }  
    pepe=document.getElementById("herror"); 
    pepe.style.background=(errores!="")?colorMal:colorBien;  
    pepe.style.border=(errores!="")?"solid 1px black":"none";  
    pepe.innerHTML=errores;  
 
    return (errores=="") 
    }