
//Define calendar(s): addCalendar ("Unique Calendar Name", "Window title", "Form element's name", Form name")
addCalendar("Calendar1", "Seleccione fecha", "orderdate", "citaform");
addCalendar("Calendar2", "Select Date", "secondinput", "citaform");

// default settings for English
// Uncomment desired lines and modify its values
// setFont("verdana", 9);
 setWidth(90, 1, 15, 1);
// setColor("#cccccc", "#A5C8EF", "#ffffff", "#ffffff", "#000000", "#A5C8EF", "#000000");
// setFontColor("#000000", "#000000", "#000000", "#000000", "#000000");
// setFormat("dd mon yyyy");
// setSize(200, 200, -200, 16);

// setWeekDay(0);
// setMonthNames("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre");
// setDayNames("Domingo", "Lunes", "Martes", "Mi�rcoles", "Jueves", "Viernes", "S�bado");
// setLinkNames("[Cerrar]", "[Borrar]");
