$(document).ready(function() {

    $('#tel').keyup(function(e){
        var telefono = $("#tel").val()
        var res = telefono.substring(0, 4)
        var resCero = telefono.substring(0, 1)
        //alert(res1)
        var cod1="0414"
        var cod2="0424"
        var cod3="0412"
        var cod4="0"
        
        if(resCero!=cod4 || res==cod1 || res==cod2 || res==cod3) {
            alert('NUMERO INCORRECTO')
            $("#tel").attr("onfocus","this.value='0'")
        }
    })
    
    $("#enviar").attr("disabled","disabled")
    var ran1=0
    var ran2=0
    var rant=0
    ran1=Math.floor(Math.random()*10)
    ran2=Math.floor(Math.random()*10)
    rant=ran1+ran2

    $("#textValidate").text("¿Cuánto es? "+ran1+" + "+ran2)
    
    $("#recaptcha_response_field").keyup(function(e){
        
        var nr=$(this).val()
        
        if( nr==rant ){
            $("#enviar").removeAttr("disabled")
        }
        else{
            $("#enviar").attr("disabled","disabled")
        }
    })
})