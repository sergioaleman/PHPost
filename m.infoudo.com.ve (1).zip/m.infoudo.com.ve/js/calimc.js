	function checkNum(str) {
	for (var i=0; i<str.length; i++) {
	var ch = str.substring(i, i + 1)
	if (ch!="." && ch!="+" && ch!="-" && ch!="e" && ch!="E" && (ch < "0" || ch > "9")) {
		alert("Ingrese un n�mero v�lido. Los decimales se indican con un punto.");
		return false
		}
	}
	return true
}



function compute(obj,val) {
	if (obj[val].value) {
	
		if (obj.molmas.value.length!=0)
			if (obj.vert.value.length!=0)
		
		 var numb=((obj.molmas.value)/((obj.vert.value)*(obj.vert.value)));
                obj.result.value=numb.toFixed(2);
               
		 if (obj.result.value<1)
		 	alert("Verifique haber colocado el Peso en kilogramos y la Estatura en metros, en las casillas correspondientes.");
		 	else		 
		 if (obj.result.value<18.5)
			            obj.status.value= "BAJO PESO"; 
		 else if (obj.result.value>=18.5 && obj.result.value<25)
			            obj.status.value= "NORMAL";
		 else if (obj.result.value>=25 && obj.result.value<30)
			            obj.status.value= "SOBREPESO";
		 else if (obj.result.value>=30 && obj.result.value<35)
			            obj.status.value= "OBESIDAD - 1"; 
		 else if (obj.result.value>=35 && obj.result.value<40)
			            obj.status.value= "OBESIDAD - 2";              
               else 
			            obj.status.value= "OBESIDAD - 3";  		
	}
}