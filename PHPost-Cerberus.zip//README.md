# PHPost
PHPost Risus es un sistema de compartimiento de enlaces que permite crear un sitio web similar a Taringa!

# Por ahora
Este repositorio servirá para que la comunidad pueda ir actualizando el código del script
