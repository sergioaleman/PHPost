<?php
include('header.php');
echo $tsSiteMap->CreateSiteMap();
?>