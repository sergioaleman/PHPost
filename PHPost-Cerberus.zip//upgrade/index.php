<?php

/**
 * @name /upgrade/index.php
 * @author PHPost Team
 * @copyright 2012
 */
error_reporting(1);
//

session_start();
$version_title = "PHPost Cerberus 3.0";
define('TS_HEADER', 'Revisión de instalación de '.$version_title);
include("functions.php");
run_validate();

function update_oldc3()
{
	global $update;
	$update = 1;
	$step = (int)$_GET['step'];
	if(!$step)  header('Location: index.php?step=1');

	list($coll, $c_coll) = include("collection.php");

	switch($step)
	{
		case 1: // Password base de datos.
			// Permisos
			$chmod = substr(sprintf('%o', fileperms('../config.inc.php')), -3);
			if($chmod != 666)
			{
				$message = 'Por favor cambia los permisos CHMOD del archivo <strong>config.inc.php</strong> a 666';
			}
			// Verificamos connección
			if ($_POST['connect'])
			{
				// Tratamos de conectar
				$db['hostname'] = $_POST['dbhost'];
				$db['username'] = $_POST['dbuser'];
				$db['password'] = $_POST['dbpass'];
				$db['database'] = $_POST['dbname'];
				
				// CONECTAMOS
				$rst = do_connect($db);

				if ($rst == 1)
				{
					// Guardamos en una variable de session para continuar el proceso.
					$_SESSION['db'] = $db;
					// Actualizamos config.inc.php
					$config = file_get_contents('../config.inc.php');
					$config = str_replace(array('dbhost', 'dbuser', 'dbpass', 'dbname'), array($db['hostname'], $db['username'], $db['password'], $db['database']), $config);
					file_put_contents('../config.inc.php',$config);
					// Segundo páso
					header("Location: index.php?step=2");
				}
				else
				{
					$message = 'Tus datos de conexi&oacute;n son incorrectos.';
				}

			}
			break;
		case 2: // Modo de instalación
			check_connection();

			if (isset($_POST['modo']))
			{
				$modo = $_POST['modo'];
				if ($modo == 'selectivo')
				{
					header("Location: index.php?step=4");
				}
				elseif ($modo == 'reinstalar')
				{
					header("Location: index.php?step=3");
				}
				else
				{
					$message = 'Modo incorrecto.';
				}
			}
			break;
		case 3: // Limpieza.
			check_connection();

			$rst_coll = procesar_limpieza_collection($coll);

			break;
		case 4: // Seleccion de actualización.
			check_connection();

			break;
		case 5: // Aplicación cambios BD.
			check_connection();

			// Verificamos el POST.
			if ( ! isset($_POST['update']) || ! is_array($_POST['update']))
			{
				header('Location: index.php?step=4&error=1');
			}
			$rst = procesar_collection($coll, $_POST['update'], $c_coll);

			break;
		case 6: // Resumen instalación.
			check_connection();
			unset($_SESSION['passwd']);
			session_destroy();

			break;
		default:
			header("Location: index.php?step=1");

	}
}

function update_r3c3()
{
	// Verificamos la versión del sistema....	
	global $connection, $update, $message;
	$query = "SELECT version_code FROM w_configuracion LIMIT 1";
	if ($result = mysqli_query($connection, $query)) {
		while ($row = mysqli_fetch_row($result)) {
			$version = $row[0];
			if($version != 'risus_1_3_0_000')
			{
				update2(2);
			}
		}
	}
}

function update_c3()
{
	// Verificamos la versión del sistema....	
	global $connection, $update, $message;
	$query = "SELECT version_code FROM w_configuracion LIMIT 1";
	if ($result = mysqli_query($connection, $query)) {
		while ($row = mysqli_fetch_row($result)) {
			$version = $row[0];
			if($version == 'cerberus_3_0_000')
			{
				update2(3);
			}
		}
	}
}
function run_validate(){
	// Verificamos la versión del sistema....	
	global $db, $connection;
    require_once('../config.inc.php');
	if($db['hostname'] == "dbhost" && $db['username'] == "dbuser" && $db['password'] == "dbpass" && $db['database'] == "dbname")
		die('El sistema no requiere una actualización, necesita instalar el sistema antes de actualizar');
	else
	{
		$connection = mysqli_connect($db['hostname'], $db['username'], $db['password'], $db['database']);
		$query = "SELECT version_code FROM w_configuracion LIMIT 1";
		if ($result = mysqli_query($connection, $query)) {
			while ($row = mysqli_fetch_row($result)) {
				$version = $row[0];
				if($version == 'cerberus_3_0_100')
				{
					update_0(0);
				}
				if($version == 'cerberus_3_0_000')
				{
					update_c3();
				}				
				else if($version == 'risus_1_3_0_000')
				{
					update_r3c3();
				}
				else
				{
					update_oldc3();
				}
			}
			mysqli_free_result($result);
		}
	}
	mysqli_close($connection);
}

function verificar_login($u, $p, $t)
{
	global $db, $connection, $message;
    require_once('../config.inc.php');
	$connection = mysqli_connect($db['hostname'], $db['username'], $db['password'], $db['database']);
	if($connection)
	{
		$p = md5(md5($p) . strtolower($u));
		$u = mysqli_real_escape_string($connection, $u);
		$q = "SELECT user_name, user_password FROM u_miembros where user_name='" . $u ."' LIMIT 1";
		if ($r = mysqli_query($connection, $q)) {
			$data = mysqli_fetch_assoc($r);
			if($data['user_name'] == $u && $data['user_password'] == $p)
			{
				if($t == 2)
				{
					run_update_rc3($connection);
				}
				else if($t == 3)
				{
					run_update_c3($connection);
				}
			}
			else
			{
				die('Los datos ingresados no son correctos');
			}
		}
		else
		{
			die('Los datos ingresados no son correctos');
		}
	}
}

function run_update_rc3($connection)
{
	$sql = array();
	// Agregamos las nuevas consultas a agregar por actualización del sistema...
	$sql[] = 'ALTER TABLE `p_posts` ADD `post_image` VARCHAR( 255 ) NOT NULL DEFAULT \'files/images/post_default.png\'';
	$sql[] = 'ALTER TABLE `u_miembros` ADD `user_cover` varchar(255) NOT NULL DEFAULT \'files/covers/cover_default.png\'';
	$sql[] = 'ALTER TABLE `w_configuracion` ADD `news` INT( 1 ) NOT NULL DEFAULT "2"';
	$sql[] = 'ALTER TABLE `w_configuracion` ADD `siteKeywords` varchar(120) NOT NULL DEFAULT ""';
	$sql[] = 'ALTER TABLE `w_configuracion` ADD `twiterUser` varchar(100) NOT NULL DEFAULT ""';
	$sql[] = 'ALTER TABLE `w_configuracion` ADD `fbAppID` varchar(55) NOT NULL DEFAULT ""';
	$sql[] = 'UPDATE w_configuracion SET version = \'Cerberus 3.0.000\', version_code = \'cerberus_3_0_000\', tema_id = \'1\' WHERE tscript_id = \'1\'';
	$sql[] = 'DELETE FROM `w_temas` WHERE `tid` != \'1\'';
	$sql[] = "CREATE TABLE IF NOT EXISTS `c_chat_zones` (
`zone_id` int(12) NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(120) NOT NULL DEFAULT '',
  `zone_perms` TEXT NULL,
  `zone_advertisement` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
	$sql[] = "INSERT INTO `c_chat_zones` (`zone_id`, `zone_name`, `zone_perms`, `zone_advertisement`) VALUES (1, 'General', '', '');";
	$sql[] = "CREATE TABLE IF NOT EXISTS `c_chat_messages` (
`msg_id` int(12) NOT NULL AUTO_INCREMENT,
  `msg_user` int(12) NOT NULL DEFAULT '0',
  `msg_zone` int(12) NOT NULL DEFAULT '1',
  `msg_text` text NULL,
  `msg_date` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
	$sql[] = "CREATE TABLE IF NOT EXISTS `c_chat_private_messages` (
  `private_id` int(12) NOT NULL AUTO_INCREMENT,
  `private_user` int(12) NOT NULL DEFAULT '0',
  `private_to_user` int(12) NOT NULL DEFAULT '0',
  `private_text` text NULL,
  `private_date` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`private_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
	$sql[] = "CREATE TABLE IF NOT EXISTS `c_chat_blacklist` (
`ban_id` int(12) NOT NULL AUTO_INCREMENT,
  `ban_user` int(12) NOT NULL DEFAULT '0',
  `ban_expire` int(12) NOT NULL DEFAULT '0',
  `ban_date` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ban_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";

	$sql[] = "ALTER TABLE `u_miembros` ADD `user_chat` INT(12) NOT NULL DEFAULT '0';";

	foreach($sql as $q)
	{
		mysqli_query($connection, $q);
	}
	die('El sistema se ha actualizado correctamente');
}
function run_update_c3($connection)
{
	$sql = array();
	// Agregamos las nuevas consultas a agregar por actualización del sistema...
	$sql[] = 'UPDATE w_configuracion SET version = \'Cerberus 3.0.100\', version_code = \'cerberus_3_0_100\', tema_id = \'1\' WHERE tscript_id = \'1\'';
	$sql[] = 'DELETE FROM `w_temas` WHERE `tid` != \'1\'';
	$sql[] = "CREATE TABLE IF NOT EXISTS `c_chat_zones` (
`zone_id` int(12) NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(120) NOT NULL DEFAULT '',
  `zone_perms` TEXT NULL,
  `zone_advertisement` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
	$sql[] = "INSERT INTO `c_chat_zones` (`zone_id`, `zone_name`, `zone_perms`, `zone_advertisement`) VALUES (1, 'General', '', '');";
	$sql[] = "CREATE TABLE IF NOT EXISTS `c_chat_messages` (
`msg_id` int(12) NOT NULL AUTO_INCREMENT,
  `msg_user` int(12) NOT NULL DEFAULT '0',
  `msg_zone` int(12) NOT NULL DEFAULT '1',
  `msg_text` text NULL,
  `msg_date` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
	$sql[] = "CREATE TABLE IF NOT EXISTS `c_chat_private_messages` (
  `private_id` int(12) NOT NULL AUTO_INCREMENT,
  `private_user` int(12) NOT NULL DEFAULT '0',
  `private_to_user` int(12) NOT NULL DEFAULT '0',
  `private_text` text NULL,
  `private_date` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`private_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
	$sql[] = "CREATE TABLE IF NOT EXISTS `c_chat_blacklist` (
`ban_id` int(12) NOT NULL AUTO_INCREMENT,
  `ban_user` int(12) NOT NULL DEFAULT '0',
  `ban_expire` int(12) NOT NULL DEFAULT '0',
  `ban_date` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ban_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";

	$sql[] = "ALTER TABLE `u_miembros` ADD `user_chat` INT(12) NOT NULL DEFAULT '0';";

	foreach($sql as $q)
	{
		mysqli_query($connection, $q);
	}
	die('El sistema se ha actualizado correctamente');
}
function update1($value)
{
	global $page;	
	$c1 = $c2 = $c3 = $c4 = $c5 = $c6 = "";
	if($_GET['step'] > 0)
		$c1 = ' class="ok"';
	if($_GET['step'] > 1)
		$c2 = ' class="ok"';
	if($_GET['step'] > 2)
		$c3 = ' class="ok"';
	if($_GET['step'] > 3)
		$c4 = ' class="ok"';
	if($_GET['step'] > 4)
		$c5 = ' class="ok"';
	if($_GET['step'] > 5)
		$c6 = ' class="ok"';
	if($message)
	{
		$page = '<div class="error">'.$message.'</div>';
		return;
	}
	if($step == 1)
	{
		$form = '<form action="index.php?step=1" method="post" id="form">
	<fieldset>
		<legend>Conexi&oacute;n</legend>
		<p>Ingresa los datos de acceso a la base de datos en d&oacute;nde actualmente tienes instalado PHPost.</p>					   
		<dl>
			<dt><label for="f1">Servidor:</label><br /><span>D&oacute;nde est&aacute; la base de datos, ej: <strong>localhost</strong></span></dt>
			<dd><input type="text" autocomplete="off" id="f1" name="dbhost" value="<?php echo $dbhost;?>" /></span></dd>
		</dl>
		<dl>
			<dt><label for="f2">Usuario:</label><br /><span>El usuario de tu base de datos.</span></dt>
			<dd><input type="text" autocomplete="off" id="f2" name="dbuser" value="<?php echo $dbuser;?>" /></span></dd>
		</dl>
		<dl>
			<dt><label for="f3">Contrase&ntilde;a:</label><br /><span>Para acceder a la base de datos.</span></dt>
			<dd><input type="password" autocomplete="off" id="f3" name="dbpass" value="<?php echo $dbpass;?>" /></span></dd>
		</dl>
		<dl>
			<dt><label for="f4">Base de datos</label><br /><span>Nombre de la base de datos para tu web.</span></dt>
			<dd><input type="text" autocomplete="off" id="f4" name="dbname" value="<?php echo $dbname;?>" /></span></dd>
		</dl>
		<p><input type="submit" name="connect" class="gbqfb" value="Conectar &raquo;"/></p>
	</fieldset>
</form>';
	}
	else if($step == 2)
	{
		$form = '<form action="index.php?step=2" method="post" id="form">
	<fieldset>
		<legend>Modo de actualizaci&oacute;n</legend>
		<dl>
			<dt class="cf"><label for="selectivo">Selectiva:</label><br /><span>Seleccionar las tablas a modificar</span></dt>
			<dd class="cf"><input type="radio" name="modo" value="selectivo" id="selectivo" checked="checked" /></dd>
			<dt class="cf"><label for="reinstalar">Reinstalar:</label><br /><span>Deshacer los cambios de la actualizaci&oacute;n e ir al modo selectivo</span></dt>
			<dd class="cf"><input type="radio" name="modo" value="reinstalar" id="reinstalar" /></dd>
		</dl>
		<p><input type="submit" name="start" class="gbqfb" value="Empezar &raquo;"/></p>
	</fieldset>
</form>';
	}
	elseif($step == 3) 
	{
		$limpieza = resultado_limpieza_html($coll, $rst_coll);
		$form = '<h2 class="s16">Resultado limpieza para reinstalación</h2>
<form action="index.php?step=4" method="post" id="form">
	<p>Leyenda:</p>
	<p>SKIP implica que no se pudo realizar la limpieza.</p>
	<p>OK que fue satisfactorio.</p>
	<p>ERROR implica que se produjo un error al intentar la limpieza.</p>
	<fieldset>
		<legend>Resultado de la limpieza de la reinstalación:</legend>
		<dl>
			'.$limpieza.'
		</dl>
		<p><input type="submit" name="select" class="gbqfb" value="Continuar &raquo;"/></p>
	</fieldset>
</form>';
	}
	else if($step == 4) 
	{
		$tablas = generate_collection($coll);
		$form = '<h2 class="s16">Selecciones procedimiento de instalación</h2>
<form action="index.php?step=5" method="post" id="form">
	<fieldset>
		<legend>Tablas a actualizar:</legend>
		<dl>
			'.$tablas.'
		</dl>
		<p><input type="submit" name="select" class="gbqfb" value="Realizar &raquo;"/></p>
	</fieldset>
</form>';						
	}
	else if($step == 5) 
	{
		$resultado = resultado_html($coll, $rst);
		$form = '<h2 class="s16">Selecciones procedimiento de instalación</h2>
<form action="index.php?step=6" method="post" id="form">
	<fieldset>
		<legend>Resultado de la actualización:</legend>
		<dl>
			'.$resultado.'
		</dl>
		<p><input type="submit" name="select" class="gbqfb" value="Continuar &raquo;"/></p>
	</fieldset>
</form>';
	}
	else if($step == 6) 
	{
		$server_name = 'http://' . $_SERVER['SERVER_NAME'];
		$base_name = basename(getcwd());
		$form = '<h2 class="s16">Bienvenido a PHPost Cerberus 3.0</h2>
<!-- ESTADISTICAS -->
<div class="error">
	Ingrese a su FTP y borre la carpeta <strong>'.$base_name.'</strong> antes de usar el script.
</div>
<fieldset style="color: #555;">
	La actualizaci&oacute;n ha sido exitosa y ahora puede volver a usar su comunidad. Gracias por usar <strong>PHPost</strong> como su sistema de compartimiento de enlaces. No deje de <a href="https://phpost.es/" target="_blank"><u>visitarnos</u></a> y estar pendiente de futuras actualizaciones. Recuerde reportar cualquier bug que encuentre para as&iacute; poder solucionarlos.<br /><br />
</fieldset>
<center>
	<input type="hidden" name="key" value="'.$key.'" />
	<a href="'.$server_name.'" class="gbqfb"style="font-size: 12pt; font-weight: bold; text-decoration:none;" >Finalizar</a>
	</center>';
	}
	$page = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">

<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="Whiteneo" />
	<title>Actualizaci&oacute;n de PHPost Alfa 1.x a Final Cerberus 3.x</title>
    <link href="estilo.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="container">
        <div id="header">
            <h1 class="s32 left"><a href="https://phpost.es" target="_blank"><img src="./logo.png" /></a></h1>
            <h3 class="s12 right">Programa de actualizaci&oacute;n de contenidos</h3>
        </div>
        <div id="content">
            <div class="col_left">
                <h3 class="s16" style="margin-bottom: 5px;;">Pasos</h3>
                <ul class="menu">
                    <li id="mstep_1"'.$c1.'>#1 | Conexi&oacute;n</li>
                    <li id="mstep_1"'.$c2.'>#2 | Modo actualizaci&oacute;n</li>
                    <li id="mstep_1"'.$c3.'>#3 | Preparaci&oacute;n</li>
                    <li id="mstep_1"'.$c4.'>#4 | Selecci&oacute;n</li>
                    <li id="mstep_1"'.$c5.'>#5 | Actualizaci&oacute;n</li>
                    <li id="mstep_1"'.$c6.'>#6 | Resumen</li>
                </ul>
            </div>
            <div class="col_right">
                <div id="step_'.$step.'" class="step">
                    <h3 class="step_num" style="margin-bottom: 5px;;">Paso #'.$step.'</h3>
					'.$form.'
                 </div>
            </div>
            <div class="clear"></div>
        </div>
        <div id="footer">
            <p><a href="https://phpost.es/" target="_blank">PHPost</a> es un producto de nueva generaci&oacute;n tipo taringa</p>
        </div>
    </div>
</body>
</html>';
	echo $page;
}
function update2($value)
{
	global $page, $paso;
	$class1 = $class2 = "";
	$step = (int)$_GET['step'];
	$paso = 0;
	$info = 'Escriba los datos de su cuenta de administrador del sistema para iniciar la actualización';
	if($value == 2)
		$title = '<title>Actualizaci&oacute;n de PHPost Risus 1.3 a Final Cerberus 3.0</title>';
	else if($value == 3)
		$title = '<title>Actualizaci&oacute;n de PHPost Cerberus 3.0 a Cerberus 3.0.1</title>';
	if(isset($_POST['start']))
	{
		$username = $_POST['username'];
		$password = $_POST['password'];
		if(empty($username) || empty($password))
		{
			$message = 'Los datos deben ser correctos';
		}
		else
		{
			verificar_login($username, $password, $value);
			$info = 'Los datos han sido comprobados correctamente';
			$form = 'Su sistema ha sido actualizado a la última versión correctamente';
			$paso = 1;
		}
	}		
	if($message)
		$message = '<div class="error">'.$message.'</div>';
	if($step == 0)
	{
		$class1 = "class=\"ok\"";
		$form = '<h3 class="step_num" style="margin-bottom: 5px;">Paso #1</h3>
<form action="index.php?step=1" method="post" id="form">
	<label for="usuario">Nombre de Usuario</label>
	<input type="text" value="" name="username" placeholder="Ingresar usuario" /><br />
	<label for="usuario">Contraseña</label>
	<input type="password" value="" name="password" placeholder="Contraseña" /><br /><br />
	<input type="submit" name="start" class="gbqfb" value="Iniciar Sesión" />
</form>';
	}
	$page = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="Whiteneo" />
	'.$title.'
    <link href="estilo.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="container">
        <div id="header">
            <h1 class="s32 left"><a href="https://phpost.es" target="_blank"><img src="./logo.png" /></a></h1>
            <h3 class="s12 right">Programa de actualizaci&oacute;n de contenidos</h3>
        </div>
        <div id="content">
            <div class="col_left">
				'.$message.'
                <h3 class="s16" style="margin-bottom: 5px;">Actualizaci&oacute;n</h3>
                <ul class="menu">
                    <li id="mstep_1"'.$class1.'>#1 | Iniciar Sesi&oacute;n</li>
                    <li id="mstep_1"'.$class2.'>#2 | Actualizar</li>
                </ul>
            </div>
            <div class="col_right">
				<span>'.$info.'</span>
                <div id="step_'.$step.'" class="step">
					'.$form.'
                </div>
            </div>
            <div class="clear"></div>
        </div>
        <div id="footer">
            <p><a href="https://phpost.es/" target="_blank">PHPost</a> es un producto de nueva generaci&oacute;n tipo taringa</p>
        </div>
    </div>
</body>
</html>';
	echo $page;
}
function update_0($value)
{
	global $page;
	$page = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">

<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="Whiteneo" />
	<title>Actualizaci&oacute;n de PHPost Final Cerberus 3.x</title>
    <link href="estilo.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <div id="container">
        <div id="header">
            <h1 class="s32 left"><a href="https://phpost.es" target="_blank"><img src="./logo.png" /></a></h1>
            <h3 class="s12 right">Programa de actualizaci&oacute;n de contenidos</h3>
        </div>
		<div id="content">
			<div class="emptyData">La versión no necesita actualizarse...</div>
            <div class="clear"></div>
        </div>
        <div id="footer">
            <p><a href="https://phpost.es/" target="_blank">PHPost</a> es un producto de nueva generaci&oacute;n tipo taringa</p>
        </div>
    </div>
</body>
</html>';
	echo $page;
}